
'use client';

import type { SummarizeTextInputOutput as SummarizeTextFlowOutput } from '@/ai/flows/summarize-text-input';
import type { AnalyzeVoiceNoteOutput as AnalyzeVoiceFlowOutput } from '@/ai/flows/analyze-voice-note';
import type { AnalyzeUploadedImageOutput as AnalyzeImageFlowOutput } from '@/ai/flows/analyze-uploaded-image';
// import type { AnalyzeAudioImageComboOutput as AnalyzeAudioImageFlowOutput } from '@/ai/flows/analyze-audio-image-combo'; // Removed
import type { AnalyzeVideoOutput as AnalyzeVideoFlowOutput } from '@/ai/flows/analyze-video-flow'; 
import type { SuperAnalysisOutput as SuperAnalysisFlowOutput } from '@/ai/flows/super-analysis-flow'; 

import { createContext, useContext, useState, ReactNode } from 'react';

export type AnalysisDataType =
  | SummarizeTextFlowOutput
  | AnalyzeVoiceFlowOutput
  | AnalyzeImageFlowOutput
  // | AnalyzeAudioImageFlowOutput // Removed
  | AnalyzeVideoFlowOutput 
  | SuperAnalysisFlowOutput; 

export type AnalysisMode = 'text' | 'audio' | 'image' | 'video' | 'super-analysis'; // Removed 'audio-image'

interface ResultsContextType {
  analysisResult: AnalysisDataType | null;
  analysisMode: AnalysisMode | null;
  setAnalysisData: (
    result: AnalysisDataType,
    mode: AnalysisMode
  ) => void;
  clearAnalysisData: () => void;
}

const ResultsContext = createContext<ResultsContextType | undefined>(undefined);

export function ResultsProvider({ children }: { children: ReactNode }) {
  const [analysisResult, setAnalysisResult] =
    useState<AnalysisDataType | null>(null);
  const [analysisMode, setAnalysisMode] = useState<AnalysisMode | null>(
    null
  );

  const setAnalysisData = (
    result: AnalysisDataType,
    mode: AnalysisMode
  ) => {
    setAnalysisResult(result);
    setAnalysisMode(mode);
  };

  const clearAnalysisData = () => {
    setAnalysisResult(null);
    setAnalysisMode(null);
  };

  return (
    <ResultsContext.Provider
      value={{
        analysisResult,
        analysisMode,
        setAnalysisData,
        clearAnalysisData,
      }}
    >
      {children}
    </ResultsContext.Provider>
  );
}

export function useResults() {
  const context = useContext(ResultsContext);
  if (context === undefined) {
    throw new Error('useResults must be used within a ResultsProvider');
  }
  return context;
}

    