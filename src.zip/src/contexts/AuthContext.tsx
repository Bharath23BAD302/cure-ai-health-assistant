
'use client';

import { createContext, useContext, useState, ReactNode, useEffect } from 'react';
// User and UserProfile types are kept for structural consistency if other parts of the app might still reference them,
// but they will always be null in the context of authentication.
import type { User } from 'firebase/auth'; // Can be removed if User type is truly unused elsewhere
import type { UserProfile } from '@/types';

interface AuthContextType {
  currentUser: User | null; // Will always be null
  userProfile: UserProfile | null; // Will always be null
  loading: boolean; // Will be false after initial setup
  logout: () => void; // Will be a no-op
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  // loading is false as there's no asynchronous auth operation
  const [loading, setLoading] = useState(false);

  // useEffect to ensure loading is definitively false after mount, though it starts as false.
  useEffect(() => {
    setLoading(false);
  }, []);

  const logout = () => {
    // No operation needed as there's no user session
    // console.log("Logout called, no user session to clear.");
  };

  const value: AuthContextType = {
    currentUser: null,
    userProfile: null,
    loading,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

