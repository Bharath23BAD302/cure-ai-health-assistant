
import type { Timestamp } from 'firebase/firestore';

export interface UserProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  createdAt: Timestamp;
}

export interface ConsultationBase {
  id: string;
  mode: 'text' | 'audio' | 'image' | 'video' | 'chat' | 'super-analysis'; // Removed 'audio-image'
  createdAt: Timestamp;
}

export interface TextConsultation extends ConsultationBase {
  mode: 'text';
  input: string;
  summary: string;
  impactScore: number;
  label: string;
  treatmentOffline: string;
  geminiAdvice: string;
  seriousness: 'low' | 'medium' | 'high';
}

export interface AudioConsultation extends ConsultationBase {
  mode: 'audio';
  fileName: string;
  summary: string;
  potentialDiagnoses: string;
  recommendedOfflineTreatments: string;
}

export interface ImageConsultation extends ConsultationBase {
  mode: 'image';
  fileName: string;
  category: string;
  confidence: number;
  label: string;
  treatmentOffline: string;
  geminiAdvice: string;
}

// Removed AudioImageConsultation interface

export interface VideoConsultation extends ConsultationBase {
  mode: 'video';
  fileName: string;
  summary: string;
  keyObservations: string[];
  potentialConcerns: string;
  durationApproximation?: string;
}

export interface ChatConsultation extends ConsultationBase { 
    mode: 'chat';
    history: Array<{sender: 'user' | 'ai', content: string, timestamp: Date}>;
    finalSummary?: string; 
}

export interface SuperAnalysisConsultation extends ConsultationBase {
    mode: 'super-analysis';
    textInputSummary?: string;
    audioInputSummary?: string;
    imageInputSummary?: string;
    videoInputSummary?: string;
    chatSummary?: string;
    analysisOutput: SuperAnalysisOutput;
}


export type Consultation = 
  | TextConsultation 
  | AudioConsultation 
  | ImageConsultation 
  // | AudioImageConsultation // Removed
  | VideoConsultation
  | ChatConsultation
  | SuperAnalysisConsultation;

// AI Flow Output Types (from individual flows)
export type { SummarizeTextInputOutput } from '@/ai/flows/summarize-text-input';
export type { AnalyzeVoiceNoteOutput } from '@/ai/flows/analyze-voice-note';
export type { AnalyzeUploadedImageOutput } from '@/ai/flows/analyze-uploaded-image';
// export type { AnalyzeAudioImageComboOutput } from '@/ai/flows/analyze-audio-image-combo'; // Removed
export type { AnalyzeVideoOutput } from '@/ai/flows/analyze-video-flow';
export type { ChatOutput as ChatAIOutput } from '@/ai/flows/chat-flow'; 
export type { SuperAnalysisOutput } from '@/ai/flows/super-analysis-flow';

    