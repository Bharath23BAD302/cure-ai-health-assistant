
'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import LoadingSpinner from '@/components/LoadingSpinner';

export default function DeprecatedHomePage() {
  const router = useRouter();

  useEffect(() => {
    router.replace('/'); // Redirect to the new home page at root
  }, [router]);

  return (
    <div className="flex items-center justify-center min-h-screen">
      <LoadingSpinner />
      <p className="ml-4">Redirecting...</p>
    </div>
  );
}
