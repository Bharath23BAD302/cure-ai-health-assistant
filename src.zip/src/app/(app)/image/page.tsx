
'use client';

import { useState, type FormEvent } from 'react';
import { useRouter } from 'next/navigation'; // Added
import { Button } from '@/components/ui/button';
import FileUpload from '@/components/FileUpload';
import { useToast } from '@/hooks/use-toast';
import LoadingSpinner from '@/components/LoadingSpinner';
// ResultsCard removed
import { analyzeUploadedImage } from '@/ai/flows/analyze-uploaded-image';
import { useResults } from '@/contexts/ResultsContext'; // Added
import { getFileAsDataURL } from '@/lib/firestore'; 
import NextImage from 'next/image';
import { Camera } from 'lucide-react';

export default function ImagePage() {
  const router = useRouter(); // Added
  const { setAnalysisData } = useResults(); // Added
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  // const [results, setResults] = useState<AnalyzeUploadedImageOutput | null>(null); // Removed
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const handleFileSelect = (file: File) => {
    setImageFile(file);
    const reader = new FileReader();
    reader.onloadend = () => {
      setImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
    // setResults(null); // Removed
    setError(null);
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!imageFile) {
      toast({ variant: 'destructive', title: 'Error', description: 'Please select an image file.' });
      return;
    }

    setLoading(true);
    setError(null);
    // setResults(null); // Removed

    try {
      const imageDataUri = await getFileAsDataURL(imageFile);
      const analysisResults = await analyzeUploadedImage({
        imageDataUri,
      });
      // setResults(analysisResults); // Removed
      setAnalysisData(analysisResults, 'image'); // Added
      router.push('/results'); // Added
      
      toast({ title: 'Analysis Complete', description: 'Redirecting to results...' });

    } catch (err: any) {
      console.error("Error processing image input:", err);
      const errorMessage = err.message || 'Failed to analyze image. Please try again.';
      setError(errorMessage);
      toast({ variant: 'destructive', title: 'Analysis Failed', description: errorMessage });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-2 text-center">Upload an Image</h1>
      <p className="text-muted-foreground text-center mb-8">
        Submit an image of the affected area (e.g., rash, X-ray) for analysis.
      </p>

      <form onSubmit={handleSubmit} className="max-w-xl mx-auto space-y-6">
        <FileUpload onFileSelect={handleFileSelect} accept="image/*" buttonText="Select Image File">
          <Camera className="w-16 h-16 text-primary mb-4" />
          <p className="text-lg font-medium text-foreground">Upload your image</p>
          <p className="text-sm text-muted-foreground">Supported formats: JPG, PNG, GIF, etc.</p>
        </FileUpload>

        {imagePreview && (
          <div className="mt-4 p-4 border rounded-md shadow-sm bg-card">
            <h3 className="text-sm font-medium mb-2 text-foreground">Image Preview: {imageFile?.name}</h3>
            <NextImage
              src={imagePreview}
              alt="Image preview"
              width={400}
              height={300}
              className="rounded-md object-contain max-h-[300px] mx-auto"
              data-ai-hint="medical preview"
            />
          </div>
        )}
        
        <Button type="submit" className="w-full" disabled={loading || !imageFile}>
          {loading ? <LoadingSpinner size="sm" /> : 'Analyze Image'}
        </Button>
      </form>

      {loading && ( // Simplified loading indicator
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50">
          <LoadingSpinner size="lg" />
        </div>
      )}

      {error && <p className="text-destructive mt-4 text-center">{error}</p>}

      {/* ResultsCard rendering removed */}
    </div>
  );
}
