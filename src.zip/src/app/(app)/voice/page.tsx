
'use client';

import { useState, type FormEvent, useRef, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import FileUpload from '@/components/FileUpload';
import { useToast } from '@/hooks/use-toast';
import LoadingSpinner from '@/components/LoadingSpinner';
import { analyzeVoiceNote } from '@/ai/flows/analyze-voice-note';
import { useResults } from '@/contexts/ResultsContext';
import { getFileAsDataURL } from '@/lib/firestore';
import { Mic, Upload, Play, StopCircle, Waves } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function VoicePage() {
  const router = useRouter();
  const { setAnalysisData } = useResults();
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [audioPreview, setAudioPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const [isRecording, setIsRecording] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [audioChunks, setAudioChunks] = useState<Blob[]>([]);
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    return () => {
      if (mediaRecorder && mediaRecorder.state === 'recording') {
        mediaRecorder.stop();
      }
      if (audioPreview) {
        URL.revokeObjectURL(audioPreview);
      }
    };
  }, [mediaRecorder, audioPreview]);

  const requestMicrophonePermission = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      setHasPermission(true);
      // We don't need to do anything with the stream here,
      // just confirm permission. It will be requested again for recording.
      stream.getTracks().forEach(track => track.stop()); // Release the mic immediately
    } catch (err) {
      console.error('Error requesting microphone permission:', err);
      setHasPermission(false);
      toast({
        variant: 'destructive',
        title: 'Microphone Access Denied',
        description: 'Please enable microphone permissions in your browser settings.',
      });
    }
  };

  const startRecording = async () => {
    if (hasPermission === false) {
        toast({ variant: 'destructive', title: 'Microphone permission denied.'});
        return;
    }
    if (hasPermission === null) { // First time, or permission not yet granted
        await requestMicrophonePermission();
        // If permission is granted now, hasPermission will be true, so we re-check.
        // Need a slight delay for state update to propagate if permission was just granted.
        setTimeout(() => {
             if (hasPermission) { // Check updated state
                 initiateRecording();
             }
        }, 100);
        return;
    }
    // If permission was already true
    initiateRecording();
  };

  const initiateRecording = async () => {
     try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const recorder = new MediaRecorder(stream);
        setMediaRecorder(recorder);

        recorder.ondataavailable = (event) => {
            setAudioChunks((prev) => [...prev, event.data]);
        };

        recorder.onstop = () => {
            stream.getTracks().forEach((track) => track.stop());
        };
        
        setAudioChunks([]);
        recorder.start();
        setIsRecording(true);
        setAudioFile(null); // Clear any uploaded file
        setAudioPreview(null); // Clear preview of uploaded file
        toast({ title: 'Recording Started', description: 'Speak into your microphone.' });
    } catch (err) {
        console.error('Error starting recording:', err);
        toast({ variant: 'destructive', title: 'Recording Error', description: 'Could not start recording.' });
        setHasPermission(false);
    }
  };

  const stopRecording = () => {
    if (mediaRecorder) {
      mediaRecorder.stop();
      setIsRecording(false);
      toast({ title: 'Recording Stopped', description: 'Processing audio...' });
    }
  };
  
  useEffect(() => {
    if (!isRecording && audioChunks.length > 0) {
      const audioBlob = new Blob(audioChunks, { type: mediaRecorder?.mimeType || 'audio/webm' });
      const recordedAudioFile = new File([audioBlob], `recording-${Date.now()}.webm`, { type: audioBlob.type });
      setAudioFile(recordedAudioFile);
      const url = URL.createObjectURL(recordedAudioFile);
      setAudioPreview(url);
      setAudioChunks([]); // Reset for next recording
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isRecording, audioChunks]); // mediaRecorder removed from deps to avoid issues with its state


  const handleFileSelect = (file: File) => {
    setAudioFile(file);
    if (audioPreview) URL.revokeObjectURL(audioPreview); // Clean up previous object URL
    setAudioPreview(URL.createObjectURL(file));
    setError(null);
    setIsRecording(false); // Ensure recording state is off if a file is uploaded
    if (mediaRecorder && mediaRecorder.state === 'recording') {
      mediaRecorder.stop();
    }
  };

  const handleSubmit = async (e?: FormEvent) => {
    if (e) e.preventDefault();
    if (!audioFile) {
      toast({ variant: 'destructive', title: 'Error', description: 'No audio provided. Please record or upload an audio file.' });
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const audioDataUri = await getFileAsDataURL(audioFile);
      const analysisResults = await analyzeVoiceNote({ audioDataUri });
      setAnalysisData(analysisResults, 'audio');
      router.push('/results');
      toast({ title: 'Analysis Complete', description: 'Redirecting to results...' });
    } catch (err: any) {
      console.error("Error processing audio input:", err);
      const errorMessage = err.message || 'Failed to analyze voice note. Please try again.';
      setError(errorMessage);
      toast({ variant: 'destructive', title: 'Analysis Failed', description: errorMessage });
    } finally {
      setLoading(false);
    }
  };
  
  useEffect(() => {
    requestMicrophonePermission();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);


  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-2 text-center">Voice Analysis</h1>
      <p className="text-muted-foreground text-center mb-8">
        Record your symptoms or upload a voice note for AI analysis.
      </p>
      
      <Tabs defaultValue="record" className="max-w-xl mx-auto">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="record">
            <Mic className="mr-2 h-4 w-4" /> Record Audio
          </TabsTrigger>
          <TabsTrigger value="upload">
            <Upload className="mr-2 h-4 w-4" /> Upload File
          </TabsTrigger>
        </TabsList>
        <TabsContent value="record">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center"><Mic className="mr-2" /> Live Recording</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6 text-center">
              {isRecording && (
                <div className="flex flex-col items-center space-y-2">
                  <Waves className="w-16 h-16 text-primary animate-pulse" />
                  <p className="text-lg font-medium text-primary">Recording...</p>
                </div>
              )}
              {!isRecording && !audioPreview && hasPermission === false && (
                 <p className="text-destructive">Microphone access denied. Please enable it in your browser settings.</p>
              )}
               {!isRecording && !audioPreview && hasPermission === null && (
                 <p className="text-muted-foreground">Requesting microphone access...</p>
              )}
              <Button
                onClick={isRecording ? stopRecording : startRecording}
                disabled={loading || (hasPermission === false && !isRecording)}
                size="lg"
                className="w-full md:w-auto"
                variant={isRecording ? "destructive" : "default"}
              >
                {isRecording ? <StopCircle className="mr-2" /> : <Play className="mr-2" />}
                {isRecording ? 'Stop Recording' : 'Start Recording'}
              </Button>
              {audioFile && audioPreview && !isRecording && (
                <div className="mt-4 p-4 border rounded-md shadow-sm bg-card">
                    <h3 className="text-sm font-medium mb-2 text-foreground">Recorded Audio: {audioFile.name}</h3>
                    <audio controls src={audioPreview} ref={audioRef} className="w-full">
                    Your browser does not support the audio element.
                    </audio>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="upload">
           <Card>
            <CardHeader>
              <CardTitle className="flex items-center"><Upload className="mr-2" /> Upload Audio File</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
                <FileUpload onFileSelect={handleFileSelect} accept="audio/*" buttonText="Select Audio File">
                    <Mic className="w-16 h-16 text-primary mb-4" />
                    <p className="text-lg font-medium text-foreground">Upload your voice recording</p>
                    <p className="text-sm text-muted-foreground">MP3, WAV, M4A, WEBM etc.</p>
                </FileUpload>
                 {audioFile && audioPreview && !isRecording && (
                    <div className="mt-4 p-4 border rounded-md shadow-sm bg-card">
                        <h3 className="text-sm font-medium mb-2 text-foreground">Audio Preview: {audioFile.name}</h3>
                        <audio controls src={audioPreview} className="w-full">
                        Your browser does not support the audio element.
                        </audio>
                    </div>
                )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="max-w-xl mx-auto mt-6">
        <Button onClick={() => handleSubmit()} className="w-full" disabled={loading || !audioFile}>
            {loading ? <LoadingSpinner size="sm" /> : 'Analyze Voice Input'}
        </Button>
      </div>


      {loading && (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50">
          <LoadingSpinner size="lg" />
        </div>
      )}

      {error && <p className="text-destructive mt-4 text-center">{error}</p>}
    </div>
  );
}
