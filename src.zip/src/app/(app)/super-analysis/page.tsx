
'use client';

import { useState, FormEvent, useRef, useEffect, ReactNode } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import FileUpload from '@/components/FileUpload';
import { useToast } from '@/hooks/use-toast';
import LoadingSpinner from '@/components/LoadingSpinner';
import { superAnalyze, type SuperAnalysisInput, ChatMessage as SuperChatMessage } from '@/ai/flows/super-analysis-flow'; // To be created
import { useResults } from '@/contexts/ResultsContext';
import { getFileAsDataURL } from '@/lib/firestore';
import NextImage from 'next/image';
import { Mic, Send, BotIcon, Upload, Video as VideoIcon, Image as ImageIcon, Waves, StopCircle, Play, Sparkles, FileText } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from '@/lib/utils';


interface DisplaySuperMessage {
  id: string;
  sender: 'user' | 'ai';
  content: string;
  timestamp: Date;
}

export default function SuperAnalysisPage() {
  const router = useRouter();
  const { setAnalysisData } = useResults();
  
  const [chatHistory, setChatHistory] = useState<DisplaySuperMessage[]>([]);
  const [chatInputText, setChatInputText] = useState('');
  const [isLoadingAiChatResponse, setIsLoadingAiChatResponse] = useState(false);
  
  const [textDescription, setTextDescription] = useState('');
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [audioPreview, setAudioPreview] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoPreview, setVideoPreview] = useState<string | null>(null);
  
  const [isRecording, setIsRecording] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [audioChunks, setAudioChunks] = useState<Blob[]>([]);
  const [hasMicPermission, setHasMicPermission] = useState<boolean | null>(null);

  const [loadingAnalysis, setLoadingAnalysis] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();
  const chatScrollAreaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatScrollAreaRef.current) {
      chatScrollAreaRef.current.scrollTo({ top: chatScrollAreaRef.current.scrollHeight, behavior: 'smooth' });
    }
  }, [chatHistory]);

  useEffect(() => {
    const requestPermission = async () => {
      try {
        await navigator.mediaDevices.getUserMedia({ audio: true });
        setHasMicPermission(true);
      } catch (err) {
        setHasMicPermission(false);
      }
    };
    requestPermission();
    return () => { // Cleanup
      if (mediaRecorder && mediaRecorder.state === 'recording') mediaRecorder.stop();
      if (audioPreview) URL.revokeObjectURL(audioPreview);
      if (imagePreview) URL.revokeObjectURL(imagePreview);
      if (videoPreview) URL.revokeObjectURL(videoPreview);
    };
  }, [mediaRecorder, audioPreview, imagePreview, videoPreview]);

  const handleChatSend = async () => {
    if (!chatInputText.trim()) return;
    const userMessage: DisplaySuperMessage = { id: Date.now().toString(), sender: 'user', content: chatInputText, timestamp: new Date() };
    setChatHistory(prev => [...prev, userMessage]);
    const currentInput = chatInputText;
    setChatInputText('');
    setIsLoadingAiChatResponse(true);

    const aiChatHistory: SuperChatMessage[] = [...chatHistory, userMessage].map(msg => ({
        role: msg.sender === 'user' ? 'user' : 'model',
        parts: [{ text: msg.content }]
    }));

    // For chat, we're just using the chat part of the superAnalyze flow for now.
    // A dedicated chat flow might be better, but this keeps it within one 'super' context.
    try {
      const response = await superAnalyze({ chatMessages: aiChatHistory }); // Send only chat for chat interactions
      const aiMessage: DisplaySuperMessage = { id: Date.now().toString() + '-ai', sender: 'ai', content: response.chatReply || "I'm ready for more details.", timestamp: new Date() };
      setChatHistory(prev => [...prev, aiMessage]);
    } catch (err: any) {
      toast({variant: 'destructive', title: 'Chat Error', description: err.message || 'AI failed to respond.'});
       setChatHistory(prev => [...prev, { id: Date.now().toString() + '-err', sender: 'ai', content: `Error: ${err.message}`, timestamp: new Date() }]);
    } finally {
      setIsLoadingAiChatResponse(false);
    }
  };

  const startRecording = async () => { /* Similar to VoicePage */ 
    if (hasMicPermission === false) {
        toast({ variant: 'destructive', title: 'Microphone access denied.'});
        return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      setMediaRecorder(recorder);
      recorder.ondataavailable = (event) => setAudioChunks((prev) => [...prev, event.data]);
      setAudioChunks([]); // Clear previous chunks
      recorder.start();
      setIsRecording(true);
      setAudioFile(null); // Clear uploaded file if any
      if(audioPreview) URL.revokeObjectURL(audioPreview);
      setAudioPreview(null);
      toast({ title: 'Recording audio...' });
    } catch (err) {
      toast({ variant: 'destructive', title: 'Recording Error', description: 'Could not start audio recording.' });
      setHasMicPermission(false);
    }
  };

  const stopRecording = () => { /* Similar to VoicePage */ 
    if (mediaRecorder) {
      mediaRecorder.stop();
      setIsRecording(false);
      
      mediaRecorder.onstop = () => { // This ensures chunks are processed after stopping
        const audioBlob = new Blob(audioChunks, { type: mediaRecorder.mimeType || 'audio/webm' });
        const recordedFile = new File([audioBlob], `super-recording-${Date.now()}.webm`, { type: audioBlob.type });
        setAudioFile(recordedFile);
        const url = URL.createObjectURL(recordedFile);
        setAudioPreview(url);
        setAudioChunks([]); // Reset for next recording
        toast({ title: 'Recording stopped.' });
         if (mediaRecorder.stream) {
            mediaRecorder.stream.getTracks().forEach(track => track.stop());
        }
      };
    }
  };

  const handleAudioFileSelect = (file: File) => { 
    setAudioFile(file); 
    if(audioPreview) URL.revokeObjectURL(audioPreview);
    setAudioPreview(URL.createObjectURL(file));
    if(isRecording) stopRecording();
  };
  const handleImageFileSelect = (file: File) => { 
    setImageFile(file); 
    if(imagePreview) URL.revokeObjectURL(imagePreview);
    setImagePreview(URL.createObjectURL(file));
  };
  const handleVideoFileSelect = (file: File) => { 
    setVideoFile(file); 
    if(videoPreview) URL.revokeObjectURL(videoPreview);
    setVideoPreview(URL.createObjectURL(file));
  };

  const handleSuperSubmit = async () => {
    if (!textDescription && !audioFile && !imageFile && !videoFile && chatHistory.length === 0) {
      toast({ variant: 'destructive', title: 'No Input', description: 'Please provide some information for analysis.' });
      return;
    }
    setLoadingAnalysis(true);
    setError(null);

    try {
      const input: SuperAnalysisInput = {
        chatMessages: chatHistory.map(msg => ({ role: msg.sender === 'user' ? 'user' : 'model', parts: [{text: msg.content}]})),
      };
      if (textDescription) input.textDescription = textDescription;
      if (audioFile) input.audioDataUri = await getFileAsDataURL(audioFile);
      if (imageFile) input.imageDataUri = await getFileAsDataURL(imageFile);
      if (videoFile) input.videoDataUri = await getFileAsDataURL(videoFile);

      const results = await superAnalyze(input);
      setAnalysisData(results, 'super-analysis');
      router.push('/results');
      toast({ title: 'Super Analysis Complete', description: 'Redirecting to results...' });

    } catch (err: any) {
      console.error("Error during super analysis:", err);
      setError(err.message || 'Failed to perform super analysis.');
      toast({ variant: 'destructive', title: 'Analysis Failed', description: err.message });
    } finally {
      setLoadingAnalysis(false);
    }
  };
  
  const InputSection = ({ title, icon, children }: {title: string, icon: ReactNode, children: ReactNode}) => (
    <Card className="overflow-hidden">
      <CardHeader className="bg-muted/30">
        <CardTitle className="text-lg flex items-center">
          {icon}
          <span className="ml-2">{title}</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4 md:p-6 space-y-4">
        {children}
      </CardContent>
    </Card>
  );


  return (
    <div className="container mx-auto py-8 px-4">
      <div className="text-center mb-8">
        <Sparkles className="w-12 h-12 text-primary mx-auto mb-2" />
        <h1 className="text-3xl md:text-4xl font-bold">Super Analysis</h1>
        <p className="text-muted-foreground mt-1">
          Combine chat, text, voice, image, and video for a comprehensive AI assessment.
        </p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Inputs Column */}
        <div className="lg:col-span-2 space-y-6">
          <InputSection title="Textual Description" icon={<FileText className="w-5 h-5" />}>
            <Textarea
              value={textDescription}
              onChange={(e) => setTextDescription(e.target.value)}
              placeholder="Describe symptoms, context, or ask specific questions related to other inputs..."
              className="min-h-[120px]"
            />
          </InputSection>
          
          <InputSection title="Voice Input" icon={<Mic className="w-5 h-5" />}>
            <Tabs defaultValue="record" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="record">Record</TabsTrigger>
                <TabsTrigger value="upload">Upload</TabsTrigger>
              </TabsList>
              <TabsContent value="record" className="mt-4 space-y-3 text-center">
                <Button onClick={isRecording ? stopRecording : startRecording} variant={isRecording ? "destructive" : "outline"} className="w-full" disabled={hasMicPermission === false}>
                  {isRecording ? <StopCircle className="mr-2"/> : <Play className="mr-2"/>}
                  {isRecording ? 'Stop Recording' : 'Start Recording'}
                </Button>
                {isRecording && <p className="text-primary animate-pulse text-sm">Recording...</p>}
                {audioPreview && audioFile && !isRecording && (
                  <audio controls src={audioPreview} className="w-full mt-2 rounded-md" />
                )}
              </TabsContent>
              <TabsContent value="upload" className="mt-4">
                <FileUpload onFileSelect={handleAudioFileSelect} accept="audio/*" className="h-auto py-6">
                  <Upload className="w-10 h-10 text-muted-foreground mb-2" />
                  <p className="text-sm">Upload audio file</p>
                </FileUpload>
                {audioPreview && audioFile && !isRecording && ( // Also show preview for uploaded file if not recording
                  <audio controls src={audioPreview} className="w-full mt-2 rounded-md" />
                )}
              </TabsContent>
            </Tabs>
          </InputSection>

          <div className="grid md:grid-cols-2 gap-6">
            <InputSection title="Image Upload" icon={<ImageIcon className="w-5 h-5" />}>
              <FileUpload onFileSelect={handleImageFileSelect} accept="image/*" className="h-auto py-6">
                <Upload className="w-10 h-10 text-muted-foreground mb-2" />
                <p className="text-sm">Upload image file</p>
              </FileUpload>
              {imagePreview && <NextImage src={imagePreview} alt="Image Preview" width={200} height={150} className="mt-2 rounded-md object-contain mx-auto max-h-[150px]" data-ai-hint="medical visual"/>}
            </InputSection>
            <InputSection title="Video Upload" icon={<VideoIcon className="w-5 h-5" />}>
              <FileUpload onFileSelect={handleVideoFileSelect} accept="video/*" className="h-auto py-6">
                 <Upload className="w-10 h-10 text-muted-foreground mb-2" />
                 <p className="text-sm">Upload video file</p>
              </FileUpload>
              {videoPreview && <video src={videoPreview} controls className="mt-2 rounded-md w-full max-h-[150px]" />}
            </InputSection>
          </div>
        </div>

        {/* Chat Column */}
        <div className="lg:col-span-1 flex flex-col h-[calc(100vh-12rem)] min-h-[400px] lg:h-auto lg:max-h-[calc(100vh-10rem)] bg-card rounded-lg shadow-md border">
            <CardHeader className="border-b">
                <CardTitle className="text-xl flex items-center">
                    <BotIcon className="w-6 h-6 mr-2 text-primary" />
                    AI Chat Interaction
                </CardTitle>
                <CardDescription>Refine your query or add details.</CardDescription>
            </CardHeader>
            <ScrollArea className="flex-grow p-4" ref={chatScrollAreaRef}>
                <div className="space-y-3">
                {chatHistory.map((msg) => (
                    <div key={msg.id} className={cn("flex items-end space-x-2 max-w-[90%]", msg.sender === 'user' ? 'ml-auto justify-end' : 'mr-auto justify-start')}>
                    {msg.sender === 'ai' && <BotIcon className="w-6 h-6 rounded-full text-primary self-start flex-shrink-0" />}
                    <div className={cn("p-2.5 rounded-lg shadow-sm", msg.sender === 'user' ? 'bg-primary text-primary-foreground rounded-br-none' : 'bg-muted text-foreground rounded-bl-none')}>
                        <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                        <p className="text-xs opacity-60 mt-1 text-right">{msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                    </div>
                    </div>
                ))}
                {isLoadingAiChatResponse && <div className="flex justify-start"><LoadingSpinner size="sm"/></div>}
                </div>
            </ScrollArea>
            <div className="p-3 border-t">
                <form onSubmit={(e) => { e.preventDefault(); handleChatSend(); }} className="flex items-center gap-2">
                <Textarea value={chatInputText} onChange={(e) => setChatInputText(e.target.value)} placeholder="Ask AI..." rows={1} className="flex-grow resize-none max-h-20 text-sm p-2" />
                <Button type="submit" size="icon" disabled={isLoadingAiChatResponse || !chatInputText.trim()}><Send className="w-4 h-4" /></Button>
                </form>
            </div>
        </div>
      </div>

      <div className="mt-10 text-center">
        <Button size="lg" onClick={handleSuperSubmit} disabled={loadingAnalysis} className="min-w-[200px] py-3 text-base">
          {loadingAnalysis ? <LoadingSpinner /> : <><Sparkles className="mr-2 w-5 h-5"/>Perform Super Analysis</>}
        </Button>
        {error && <p className="text-destructive mt-4">{error}</p>}
      </div>
      
      {loadingAnalysis && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="text-center p-6 bg-card rounded-lg shadow-xl">
            <LoadingSpinner size="lg" />
            <p className="mt-4 text-lg font-medium text-foreground">Performing Super Analysis...</p>
            <p className="text-muted-foreground">This may take a few moments.</p>
          </div>
        </div>
      )}
    </div>
  );
}
