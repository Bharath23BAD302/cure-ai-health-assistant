
'use client';

import { useState, type FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import FileUpload from '@/components/FileUpload';
import { useToast } from '@/hooks/use-toast';
import LoadingSpinner from '@/components/LoadingSpinner';
import { analyzeVideo } from '@/ai/flows/analyze-video-flow'; // To be created
import { useResults } from '@/contexts/ResultsContext';
import { getFileAsDataURL } from '@/lib/firestore';
import NextImage from 'next/image'; // Keep for consistency, or use HTML video
import { Video as VideoIcon, Upload } from 'lucide-react';

export default function VideoPage() {
  const router = useRouter();
  const { setAnalysisData } = useResults();
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoPreview, setVideoPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const handleFileSelect = (file: File) => {
    setVideoFile(file);
    if (videoPreview) {
      URL.revokeObjectURL(videoPreview); // Clean up previous object URL
    }
    const url = URL.createObjectURL(file);
    setVideoPreview(url);
    setError(null);
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!videoFile) {
      toast({ variant: 'destructive', title: 'Error', description: 'Please select a video file.' });
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const videoDataUri = await getFileAsDataURL(videoFile);
      const analysisResults = await analyzeVideo({ videoDataUri });
      setAnalysisData(analysisResults, 'video');
      router.push('/results');
      toast({ title: 'Video Analysis Complete', description: 'Redirecting to results...' });
    } catch (err: any) {
      console.error("Error processing video input:", err);
      const errorMessage = err.message || 'Failed to analyze video. Please try again.';
      setError(errorMessage);
      toast({ variant: 'destructive', title: 'Analysis Failed', description: errorMessage });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-2 text-center">Video Analysis</h1>
      <p className="text-muted-foreground text-center mb-8">
        Upload a video for AI-powered analysis (e.g., showing movement, environment).
      </p>

      <form onSubmit={handleSubmit} className="max-w-xl mx-auto space-y-6">
        <FileUpload onFileSelect={handleFileSelect} accept="video/*" buttonText="Select Video File">
          <VideoIcon className="w-16 h-16 text-primary mb-4" />
          <p className="text-lg font-medium text-foreground">Upload your video</p>
          <p className="text-sm text-muted-foreground">Supported formats: MP4, MOV, WEBM, etc.</p>
        </FileUpload>

        {videoPreview && videoFile && (
          <div className="mt-4 p-4 border rounded-md shadow-sm bg-card">
            <h3 className="text-sm font-medium mb-2 text-foreground">Video Preview: {videoFile.name}</h3>
            <video
              src={videoPreview}
              controls
              className="rounded-md object-contain max-h-[300px] w-full mx-auto"
            />
          </div>
        )}
        
        <Button type="submit" className="w-full" disabled={loading || !videoFile}>
          {loading ? <LoadingSpinner size="sm" /> : 'Analyze Video'}
        </Button>
      </form>

      {loading && (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50">
          <LoadingSpinner size="lg" />
        </div>
      )}

      {error && <p className="text-destructive mt-4 text-center">{error}</p>}
    </div>
  );
}
