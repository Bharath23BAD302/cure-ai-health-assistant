
'use client';

import type { ReactNode } from 'react';
// useAuth and LoadingSpinner are no longer needed here as authentication checks are removed.

export default function AppLayout({ children }: { children: ReactNode }) {
  // No authentication checks or loading state based on authentication needed anymore.
  // The AuthContext still wraps the app in RootLayout, but its state is simplified.
  return <>{children}</>;
}

