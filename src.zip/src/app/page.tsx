
'use client';

import { useState, FormEvent, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import LoadingSpinner from '@/components/LoadingSpinner';
import { chatWithAI, type ChatMessage } from '@/ai/flows/chat-flow'; 
import NextImage from 'next/image';
import { Send, BotIcon, ThumbsUp, ThumbsDown } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

// Define message structure for chat history
interface DisplayMessage {
  id: string;
  sender: 'user' | 'ai';
  content: string;
  timestamp: Date;
  feedback?: 'good' | 'bad';
}

export default function HomePage() {
  const [chatHistory, setChatHistory] = useState<DisplayMessage[]>([]);
  const [userInputText, setUserInputText] = useState('');
  const [isLoadingAiResponse, setIsLoadingAiResponse] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom of chat
  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTo({ top: scrollAreaRef.current.scrollHeight, behavior: 'smooth' });
    }
  }, [chatHistory]);
  

  const handleSendMessage = async (messageContent: string) => {
    if (!messageContent.trim()) return;

    const userMessage: DisplayMessage = {
      id: Date.now().toString() + '-user',
      sender: 'user',
      content: messageContent,
      timestamp: new Date(),
    };
    setChatHistory((prev) => [...prev, userMessage]);
    setUserInputText(''); // Clear text input
    setIsLoadingAiResponse(true);
    setError(null);

    // Prepare history for AI
    const aiHistory: ChatMessage[] = chatHistory.map(msg => ({
      role: msg.sender === 'user' ? 'user' : 'model',
      parts: [{ text: msg.content }]
    }));
     aiHistory.push({role: 'user', parts: [{text: messageContent}]});


    try {
      const aiResponse = await chatWithAI({
        message: messageContent, // Current message
        history: aiHistory.slice(0, -1) // History up to the current message
      });

      const aiMessage: DisplayMessage = {
        id: Date.now().toString() + '-ai',
        sender: 'ai',
        content: aiResponse.reply,
        timestamp: new Date(),
      };
      setChatHistory((prev) => [...prev, aiMessage]);
    } catch (err: any) {
      console.error("Error with AI chat:", err);
      const errorMessage = err.message || 'AI failed to respond. Please try again.';
      setError(errorMessage);
      setChatHistory((prev) => [...prev, {
        id: Date.now().toString() + '-error',
        sender: 'ai', content: `Error: ${errorMessage}`, timestamp: new Date()
      }]);
      toast({ variant: 'destructive', title: 'Chat Error', description: errorMessage });
    } finally {
      setIsLoadingAiResponse(false);
    }
  };

  const handleTextSubmit = (e: FormEvent) => {
    e.preventDefault();
    handleSendMessage(userInputText);
  };
  
  const handleFeedback = (messageId: string, feedback: 'good' | 'bad') => {
    setChatHistory(prev => prev.map(msg => msg.id === messageId ? {...msg, feedback} : msg));
    toast({title: "Feedback received", description: `Marked message as ${feedback}.`})
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] container mx-auto py-4 px-2 md:px-4">
      <div className="flex items-center justify-center mb-4">
        <BotIcon className="w-10 h-10 text-primary mr-2" />
        <h1 className="text-3xl font-bold text-center md:text-left">
          CURE-AI Chat Assistant
        </h1>
      </div>
      
      <ScrollArea className="flex-grow p-4 border rounded-lg shadow-inner bg-muted/30 mb-4" ref={scrollAreaRef}>
        <div className="space-y-4">
          {chatHistory.map((msg) => (
            <div
              key={msg.id}
              className={cn(
                "flex items-end space-x-2 max-w-[85%] md:max-w-[75%] animate-in fade-in-0 slide-in-from-bottom-4 duration-300",
                msg.sender === 'user' ? 'ml-auto justify-end' : 'mr-auto justify-start'
              )}
            >
              {msg.sender === 'ai' && (
                <NextImage src="https://placehold.co/40x40.png" alt="AI Avatar" data-ai-hint="bot avatar" width={32} height={32} className="rounded-full w-8 h-8 self-start flex-shrink-0" />
              )}
              <div
                className={cn(
                  "p-3 rounded-xl shadow-md", 
                  msg.sender === 'user'
                    ? 'bg-primary text-primary-foreground rounded-br-none'
                    : 'bg-card text-card-foreground rounded-bl-none'
                )}
              >
                <p className="whitespace-pre-wrap">{msg.content}</p>
                <p className="text-xs opacity-70 mt-1 text-right">
                    {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
                 {msg.sender === 'ai' && !msg.content.startsWith("Error:") && (
                    <div className="mt-1.5 flex justify-end space-x-1 opacity-50 group-hover:opacity-100 transition-opacity">
                        <Button variant="ghost" size="icon" className={`h-5 w-5 ${msg.feedback === 'good' ? 'text-green-500 opacity-100' : 'hover:text-green-500'}`} onClick={() => handleFeedback(msg.id, 'good')}><ThumbsUp className="h-3 w-3" /></Button>
                        <Button variant="ghost" size="icon" className={`h-5 w-5 ${msg.feedback === 'bad' ? 'text-red-500 opacity-100' : 'hover:text-red-500'}`} onClick={() => handleFeedback(msg.id, 'bad')}><ThumbsDown className="h-3 w-3" /></Button>
                    </div>
                )}
              </div>
               {msg.sender === 'user' && (
                 <NextImage src="https://placehold.co/40x40.png" alt="User Avatar" data-ai-hint="user avatar" width={32} height={32} className="rounded-full w-8 h-8 self-start flex-shrink-0" />
              )}
            </div>
          ))}
          {isLoadingAiResponse && chatHistory.length > 0 && chatHistory[chatHistory.length-1].sender === 'user' && (
             <div className="flex items-end space-x-2 max-w-[85%] md:max-w-[75%] mr-auto justify-start animate-in fade-in-0 duration-300">
                <NextImage src="https://placehold.co/40x40.png" alt="AI Avatar" data-ai-hint="bot avatar" width={32} height={32} className="rounded-full w-8 h-8 self-start flex-shrink-0" />
                <div className="p-3 rounded-xl shadow-md bg-card text-card-foreground rounded-bl-none">
                    <LoadingSpinner size="sm" />
                </div>
            </div>
          )}
        </div>
      </ScrollArea>

      {error && <p className="text-destructive text-sm mb-2 text-center">{error}</p>}

      <div className="flex items-center gap-2 p-2 border-t bg-background">
        <form onSubmit={handleTextSubmit} className="flex-grow flex items-center gap-2">
        <Textarea
            value={userInputText}
            onChange={(e) => setUserInputText(e.target.value)}
            placeholder="Type your message or describe symptoms..."
            className="flex-grow resize-none p-3 rounded-lg shadow-sm focus:ring-primary focus:border-primary max-h-28"
            onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleTextSubmit(e);
            }
            }}
            rows={1}
            aria-label="Chat message input"
        />
        <Button type="submit" size="icon" disabled={isLoadingAiResponse || !userInputText.trim()} aria-label="Send message" className="h-12 w-12 rounded-full">
            <Send className="h-6 w-6" />
        </Button>
        </form>
      </div>
    </div>
  );
}
