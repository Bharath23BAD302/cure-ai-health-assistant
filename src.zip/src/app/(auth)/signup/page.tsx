
'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import LoadingSpinner from '@/components/LoadingSpinner';

export default function RemovedSignUpPage() {
  const router = useRouter();

  useEffect(() => {
    router.replace('/'); // Redirect to home as sign-up is removed
  }, [router]);

  return (
    <div className="flex items-center justify-center min-h-screen">
      <LoadingSpinner />
      <p className="ml-4">Redirecting...</p>
    </div>
  );
}
