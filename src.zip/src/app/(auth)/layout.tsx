
'use client';

import type { ReactNode } from 'react';

// This layout is kept minimal in case other routes were intended under (auth)
// but it no longer provides specific auth-related functionalities like redirection.
export default function AuthLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-4rem)] py-12 sm:px-6 lg:px-8">
      {children}
    </div>
  );
}
