
'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useResults, type AnalysisDataType, type AnalysisMode } from '@/contexts/ResultsContext';
import ResultsCard from '@/components/ResultsCard';
import { Button } from '@/components/ui/button';
import LoadingSpinner from '@/components/LoadingSpinner'; // For redirect case

export default function AnalysisResultsPage() {
  const router = useRouter();
  const { analysisResult, analysisMode, clearAnalysisData } = useResults();

  useEffect(() => {
    // If there are no results in context (e.g., direct navigation or page refresh),
    // redirect to the home page.
    if (!analysisResult || !analysisMode) {
      // To prevent flashing the "No results" message before redirecting,
      // we can add a small delay or just redirect immediately.
      // For simplicity, redirecting immediately.
      router.replace('/');
    }
  }, [analysisResult, analysisMode, router]);

  const handleNewAnalysis = () => {
    clearAnalysisData();
    router.push('/');
  };

  if (!analysisResult || !analysisMode) {
    // This content will be shown briefly if redirection isn't instantaneous,
    // or if the user somehow lands here without context being set.
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-10rem)]">
        <LoadingSpinner />
        <p className="mt-4 text-muted-foreground">Loading results or redirecting...</p>
      </div>
    );
  }

  // Cast is safe here because we check for null analysisResult and analysisMode above
  // And ResultsCard expects specific types based on mode, which our context should provide.
  const typedAnalysisResult = analysisResult as NonNullable<AnalysisDataType>;
  const typedAnalysisMode = analysisMode as NonNullable<AnalysisMode>;


  return (
    <div className="container mx-auto py-8 px-4 max-w-2xl">
      <ResultsCard mode={typedAnalysisMode} data={typedAnalysisResult} />
      <div className="mt-8 flex justify-center">
        <Button onClick={handleNewAnalysis} size="lg">
          Start New Analysis
        </Button>
      </div>
    </div>
  );
}
