
import { config } from 'dotenv';
config();

import '@/ai/flows/analyze-uploaded-image.ts';
import '@/ai/flows/summarize-text-input.ts';
import '@/ai/flows/analyze-voice-note.ts';
// import '@/ai/flows/analyze-audio-image-combo.ts'; // Removed
import '@/ai/flows/analyze-video-flow.ts'; 
import '@/ai/flows/chat-flow.ts'; 
import '@/ai/flows/super-analysis-flow.ts'; 

    