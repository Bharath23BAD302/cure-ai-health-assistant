
'use server';

/**
 * @fileOverview Video analysis flow using Genkit for health-related observations.
 *
 * - analyzeVideo - Analyzes a video and provides a summary, key observations, and potential concerns relevant to health.
 * - AnalyzeVideoInput - Input type for the analyzeVideo function.
 * - AnalyzeVideoOutput - Return type for the analyzeVideo function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AnalyzeVideoInputSchema = z.object({
  videoDataUri: z
    .string()
    .describe(
      "The video data URI. It must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'. The video might show physical symptoms, movements, gait, range of motion, speech, breathing patterns, or environmental context relevant to health."
    ),
});
export type AnalyzeVideoInput = z.infer<typeof AnalyzeVideoInputSchema>;

const AnalyzeVideoOutputSchema = z.object({
  summary: z.string().describe('A concise summary of the video content, focusing on elements potentially relevant to health observations (e.g., type of activity, environment, observed behaviors or symptoms like cough, tremor, skin changes).'),
  keyObservations: z.array(z.string()).describe('A list of specific, objective observations from the video that might be medically relevant. Examples: "Limited range of motion in left shoulder during arm raise," "Visible erythematous rash on forearm during movement," "Audible wheezing sounds during speech," "Unsteady gait with wide base," "Slurred speech patterns observed."'),
  potentialConcerns: z.string().describe('A brief statement on any general concerns the video might raise from a health perspective, or aspects a healthcare professional might want to look into further. This is NOT a diagnosis. E.g., "The observed tremor and gait unsteadiness warrant further investigation by a neurologist or primary care physician." or "No immediate obvious major concerns from the visual/auditory information, but user-described symptoms (if any) should be primary for medical consultation." Always include a recommendation to see a doctor if any concerns exist.'),
  durationApproximation: z.string().optional().describe('Approximation of video duration if determinable (e.g., "approx. 15 seconds", "short clip under 30 seconds").'),
});
export type AnalyzeVideoOutput = z.infer<typeof AnalyzeVideoOutputSchema>;

export async function analyzeVideo(
  input: AnalyzeVideoInput
): Promise<AnalyzeVideoOutput> {
  return analyzeVideoFlow(input);
}

const analyzeVideoPrompt = ai.definePrompt({
  name: 'analyzeVideoPrompt',
  input: {schema: AnalyzeVideoInputSchema},
  output: {schema: AnalyzeVideoOutputSchema},
  prompt: `You are an AI assistant specialized in analyzing video content for potential health-related observations.
The user has uploaded a video, likely to show symptoms or health-related activity. Your task is to carefully analyze it and extract information that could be relevant for a health assessment, WITHOUT MAKING ANY DIAGNOSES.

Video: {{media url=videoDataUri}}

Analyze the video with these objectives, focusing on medical relevance:
1.  **Summary**: Provide a brief overview of what the video depicts. What is happening? Who is in it (if discernible, e.g., "adult male performing a task")? What is the general context or environment if relevant to health?
2.  **Key Observations**: List specific, objective visual and auditory (if applicable) observations from the video that could be medically relevant. Examples:
    *   Movement: Range of motion (e.g., "restricted shoulder abduction"), speed, symmetry, tremors, limping, stiffness, coordination, balance.
    *   Visible Symptoms: Skin changes (rashes, swelling, discoloration observed during movement or close-up), injuries, physical manifestations (e.g., "facial asymmetry noted during speech").
    *   Behavior: Signs of discomfort, pain expressions, level of activity, interaction with environment related to physical capability.
    *   Auditory Cues: Coughing (type, frequency), wheezing, shortness of breath sounds, slurred speech, voice hoarseness, tone of voice (if indicative of distress).
3.  **Potential Concerns**: Based on your observations, what general areas might warrant further attention from a healthcare professional? This should be very general (e.g., "The video shows a persistent dry cough and audible wheezing that might need checking by a doctor," or "The unsteadiness and difficulty with fine motor tasks observed could be explored further with a medical professional"). Do not suggest specific conditions. If no specific concerns are apparent from the video, state that.
4.  **Duration Approximation (Optional)**: If easily determinable, provide an approximate duration of the video.

Your response must adhere to the JSON output schema.
**Crucially, always remind the user that this analysis is NOT a medical diagnosis and they should consult a qualified healthcare professional for any health concerns, proper diagnosis, and treatment plan.** Focus on objective descriptions of what is seen and heard.
`,
});

const analyzeVideoFlow = ai.defineFlow(
  {
    name: 'analyzeVideoFlow',
    inputSchema: AnalyzeVideoInputSchema,
    outputSchema: AnalyzeVideoOutputSchema,
  },
  async input => {
    const {output} = await analyzeVideoPrompt(input);
    return output!;
  }
);

    
