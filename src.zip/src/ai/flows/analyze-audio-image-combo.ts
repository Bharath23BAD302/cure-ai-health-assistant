
'use server';

/**
 * @fileOverview Combined audio and image analysis flow.
 *
 * - analyzeAudioImageCombo - Analyzes an audio recording and an image to provide a combined assessment.
 * - AnalyzeAudioImageComboInput - Input type for the analyzeAudioImageCombo function.
 * - AnalyzeAudioImageComboOutput - Return type for the analyzeAudioImageCombo function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AnalyzeAudioImageComboInputSchema = z.object({
  audioDataUri: z
    .string()
    .describe(
      "The audio data URI of the voice note. It must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
  imageDataUri: z
    .string()
    .describe(
      "A photo of the affected area, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type AnalyzeAudioImageComboInput = z.infer<typeof AnalyzeAudioImageComboInputSchema>;

const AnalyzeAudioImageComboOutputSchema = z.object({
  overallAssessment: z.string().describe('A comprehensive summary based on both audio and image analysis.'),
  audioDerivedInsights: z.string().describe('Specific insights derived primarily from the audio input.'),
  imageDerivedInsights: z.string().describe('Specific insights derived primarily from the image input.'),
  potentialConditions: z.array(z.string()).describe('A list of potential medical conditions that could explain these symptoms and observations.'),
  treatmentRecommendations: z.string().describe('Combined treatment recommendations or next steps.'),
  confidenceScore: z.number().min(0).max(1).describe('An overall confidence score for the assessment (0-1).')
});
export type AnalyzeAudioImageComboOutput = z.infer<typeof AnalyzeAudioImageComboOutputSchema>;

export async function analyzeAudioImageCombo(
  input: AnalyzeAudioImageComboInput
): Promise<AnalyzeAudioImageComboOutput> {
  return analyzeAudioImageComboFlow(input);
}

const analyzeAudioImageComboPrompt = ai.definePrompt({
  name: 'analyzeAudioImageComboPrompt',
  input: {schema: AnalyzeAudioImageComboInputSchema},
  output: {schema: AnalyzeAudioImageComboOutputSchema},
  prompt: `You are an expert medical AI assistant. You have received an audio recording describing a patient's symptoms and an image of an affected area. Analyze both inputs carefully.

Provide:
1.  An **overallAssessment**: A comprehensive summary synthesizing information from both the audio and the image.
2.  **audioDerivedInsights**: Key symptoms or observations derived specifically from the audio.
3.  **imageDerivedInsights**: Key observations or characteristics derived specifically from the image.
4.  **potentialConditions**: A list of potential medical conditions (as an array of strings) that could explain these symptoms and observations.
5.  **treatmentRecommendations**: Suggested next steps or offline treatment advice based on the combined analysis.
6.  A **confidenceScore** (a number between 0.0 and 1.0) for your overall assessment.

Audio: {{media url=audioDataUri}}
Image: {{media url=imageDataUri}}`,
});

const analyzeAudioImageComboFlow = ai.defineFlow(
  {
    name: 'analyzeAudioImageComboFlow',
    inputSchema: AnalyzeAudioImageComboInputSchema,
    outputSchema: AnalyzeAudioImageComboOutputSchema,
  },
  async input => {
    const {output} = await analyzeAudioImageComboPrompt(input);
    return output!;
  }
);
