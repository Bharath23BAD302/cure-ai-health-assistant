
'use server';

/**
 * @fileOverview Comprehensive multi-modal medical analysis flow.
 *
 * - superAnalyze - Analyzes combined inputs from chat, text, audio, image, and video to provide a holistic, detailed medical assessment (non-diagnostic).
 * - SuperAnalysisInput - Input type for the superAnalyze function.
 * - SuperAnalysisOutput - Return type for the superAnalyze function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ChatMessageSchema = z.object({
  role: z.enum(['user', 'model']),
  parts: z.array(z.object({ text: z.string() })),
});
export type ChatMessage = z.infer<typeof ChatMessageSchema>;

const SuperAnalysisInputSchema = z.object({
  chatMessages: z.array(ChatMessageSchema).optional().describe('Ongoing chat conversation for context, specific questions, or iterative refinement of the medical analysis. User might be describing symptoms or asking about conditions.'),
  textDescription: z.string().optional().describe('A detailed text description of symptoms, medical history, lifestyle factors, or specific health concerns the user wants addressed. Include details like onset, duration, severity, and any treatments tried.'),
  audioDataUri: z.string().optional().describe("An audio recording (e.g., voice note describing symptoms, coughing sounds, speech patterns indicating health status) as a data URI. The AI should listen for nuances in speech, sounds, and content relevant to medical assessment."),
  imageDataUri: z.string().optional().describe("An image (e.g., photo of affected area, rash, swelling, wound, or general appearance if relevant) as a data URI. The AI should perform detailed visual analysis for medical indicators."),
  videoDataUri: z.string().optional().describe("A video (e.g., showing movement, range of motion, progression of a visible symptom, seizures, breathing patterns, gait) as a data URI. The AI should analyze both visual and auditory information for medical insights."),
});
export type SuperAnalysisInput = z.infer<typeof SuperAnalysisInputSchema>;

const SuperAnalysisOutputSchema = z.object({
  chatReply: z.string().optional().describe("AI's direct reply if the interaction is primarily a chat dialogue within the super-analysis context, or if a direct question was posed in the latest chat message. Should be empathetic and medically informed."),
  overallSummary: z.string().describe('A comprehensive, synthesized summary integrating insights from ALL provided inputs (chat, text, audio, image, video). This should be the cornerstone of the analysis, highlighting the most salient medical points, potential connections between observations from different modalities, and an overall impression of the health situation described (without diagnosing).'),
  symptomBreakdown: z.array(z.object({
    symptom: z.string().describe('A clearly identified symptom, sign, or medically relevant observation.'),
    mentionedIn: z.array(z.string()).describe('Modalities where this symptom was observed or described (e.g., "text", "audio - cough sound", "image - skin redness", "video - unsteady gait"). Helps trace information source for medical review.')
  })).optional().describe('A structured breakdown of key symptoms and observations, indicating which input modality contributed to their identification. Focus on medically significant findings.'),
  textAnalysisDetails: z.string().optional().describe('Specific medical insights, key phrases, and interpretations derived *primarily* from the textDescription input. What did the text uniquely contribute to understanding the health picture? E.g., "User reports a 3-day history of X symptom with Y severity."'),
  audioAnalysisDetails: z.string().optional().describe('Specific medical insights derived *primarily* from the audioDataUri. This includes transcribed symptoms, observed auditory cues (e.g., "Persistent dry cough noted", "Voice sounds hoarse", "Wheezing audible").'),
  imageAnalysisDetails: z.string().optional().describe('Specific medical insights derived *primarily* from the imageDataUri. Detailed visual description (color, shape, texture, size, distribution of findings like rashes, lesions, swelling) and what these visual cues generally imply in a medical context, without diagnosing. E.g., "Image shows an erythematous maculopapular rash on the forearm."'),
  videoAnalysisDetails: z.string().optional().describe('Specific medical insights derived *primarily* from the videoDataUri. Analysis of movement (gait, range of motion, tremors), behavior (signs of pain/distress), progression, environment (if relevant), and any combined visual/auditory cues from the video relevant to health. E.g., "Video demonstrates limited abduction of the right shoulder."'),
  potentialConditions: z.array(z.string()).optional().describe('Based on the HOLISTIC view from all inputs, list general categories of conditions or types of medical issues that *might* align with the constellation of observations (e.g., "inflammatory skin condition with possible allergic component", "respiratory issue affecting upper airways", "musculoskeletal discomfort with signs of restricted mobility", "neurological indicators requiring assessment"). **CRITICAL: AVOID SPECIFIC DIAGNOSES.** Frame these as general possibilities for a doctor to explore. Must include a disclaimer that this is not a diagnosis.'),
  suggestedNextSteps: z.string().optional().describe('Clear, actionable recommendations for the user. This should almost always include consulting a healthcare professional (e.g., "Based on these observations, it is highly recommended to consult your primary care physician or a specialist like a dermatologist for a proper evaluation and diagnosis."). May also include advice on what information from this AI analysis to prepare for the doctor visit.'),
  confidenceAssessment: z.string().optional().describe('A qualitative assessment of the AI\'s confidence in the overall analysis (e.g., "High - based on clear, consistent, and detailed information across multiple inputs", "Medium - some inputs provide good detail but others are ambiguous or limited, making a comprehensive assessment challenging", "Low - information is sparse, conflicting, or of poor quality, limiting the ability to form a comprehensive overview"). Explain the reasoning for this confidence level, considering the quality and concordance of medical information.'),
  importantQuestionsToAskDoctor: z.array(z.string()).optional().describe('A list of 2-4 pertinent questions the user might consider asking their healthcare professional, derived from the analysis to facilitate a more productive consultation (e.g., "Could my symptoms X and Y be related?", "What types of tests would help clarify the cause of Z?", "Are there any lifestyle modifications I should consider based on these observations?").'),
});
export type SuperAnalysisOutput = z.infer<typeof SuperAnalysisOutputSchema>;

export async function superAnalyze(
  input: SuperAnalysisInput
): Promise<SuperAnalysisOutput> {
  return superAnalysisFlow(input);
}

const superAnalysisPrompt = ai.definePrompt({
  name: 'superAnalysisPrompt',
  input: {schema: SuperAnalysisInputSchema},
  output: {schema: SuperAnalysisOutputSchema},
  prompt: `You are CURE-AI Pro, an advanced AI healthcare assistant performing a "Super Analysis".
Your primary objective is to conduct a thorough, multi-modal synthesis of all provided information (chat, text, audio, image, video) to offer the user a detailed, insightful, medically-informed, and actionable (but strictly non-diagnostic) overview of their potential health situation.

**Core Instructions for Medical Super Analysis:**
*   **Synthesize, Don't Just List**: Connect the dots between different inputs. If text mentions "itchy rash" and an image shows red, bumpy skin, your analysis must link these as part of the same potential issue. Look for corroborating or conflicting information across modalities.
*   **Prioritize Safety & Ethics**:
    *   NEVER PROVIDE A MEDICAL DIAGNOSIS. This is paramount.
    *   Always strongly advise consultation with a qualified healthcare professional (doctor, specialist) for diagnosis, treatment, or any medical decisions.
    *   Do not recommend specific medications or treatments.
*   **Be Comprehensive and Medically Detailed**: Address each relevant section of the output schema with as much medically relevant detail as possible, derived from the inputs.
*   **Maintain Empathy and Professionalism**: The user may be anxious; your tone should be supportive, clear, and professional.

**Inputs Provided (some may be absent):**
{{#if chatMessages}}
Chat History (provides context, user's narrative, and direct questions about their health):
{{#each chatMessages}}
{{role}}: {{parts.[0].text}}
{{/each}}
---
{{/if}}
{{#if textDescription}}
User's Text Description (detailed symptoms, medical history, lifestyle, specific health concerns):
"{{{textDescription}}}"
---
{{/if}}
{{#if audioDataUri}}
Audio Input (voice notes with symptom descriptions, coughs, breathing sounds, speech abnormalities): {{media url=audioDataUri}}
(Task: Transcribe/summarize spoken symptoms. Analyze sound characteristics like cough type (wet/dry), breathing patterns (wheezing, labored), voice changes (hoarseness) if medically relevant.)
---
{{/if}}
{{#if imageDataUri}}
Image Input (photos of affected areas, rashes, wounds, swelling, lesions, general appearance): {{media url=imageDataUri}}
(Task: Describe visual medical characteristics like color, shape, texture, borders, distribution of findings. Note any anomalies. Correlate with text/audio descriptions if possible. E.g., "Image shows an erythematous, macular rash with irregular borders located on the left forearm.")
---
{{/if}}
{{#if videoDataUri}}
Video Input (movement, range of motion, gait, visible symptoms over time, seizures, breathing patterns, environment): {{media url=videoDataUri}}
(Task: Analyze motion (e.g., "limited range of motion in the right knee"), gait ("antalgic gait observed"), visible symptoms, environmental factors. Note any changes or progressions if the video implies duration. Correlate with other inputs. E.g., "Video demonstrates tremor in the hands at rest.")
---
{{/if}}

**Your Detailed Medical Analysis Task (fulfill all relevant sections based on provided inputs):**

1.  **Chat Reply (if applicable and chat is the primary mode or a direct question is asked):**
    *   If the interaction involves ongoing chat, provide an empathetic and medically informed 'chatReply'.

2.  **Overall Summary (Most Important - Synthesize Everything Medically):**
    *   Provide a holistic medical overview. What is the main health picture emerging from all inputs combined?
    *   Highlight connections and discrepancies: e.g., "The user described X in text, which seems consistent with the Y observed in the image and the Z sound in the audio. However, the video shows A, which may need further clarification."
    *   Focus on the most medically significant findings from a general perspective.

3.  **Symptom Breakdown (if multiple distinct symptoms/observations):**
    *   List key medically relevant symptoms, signs, or observations. For each, specify which input(s) (text, audio, image, video, chat) mentioned or showed it. E.g., Symptom: "Shortness of Breath", Mentioned In: "text, audio - wheezing".

4.  **Detailed Analysis per Modality (only if the input was provided, focus on medical relevance):**
    *   **textAnalysisDetails**: What specific medical information, duration, severity, or context did the text provide?
    *   **audioAnalysisDetails**: What medically relevant information was heard? Transcribe key symptom descriptions. Describe relevant sounds (cough type, breathing issues).
    *   **imageAnalysisDetails**: Detailed visual medical description. What patterns or anomalies are visible? (e.g., "The lesion is approximately 2cm in diameter, asymmetrical, with varied pigmentation.")
    *   **videoAnalysisDetails**: What did the video show dynamically that is medically relevant? (e.g., "Difficulty bearing weight on the left leg was observed.")

5.  **Potential Conditions (General Categories - EXTREME CAUTION):**
    *   Based on the *entire picture*, suggest 2-3 *broad categories* of medical issues that a doctor *might* consider exploring. Examples: "inflammatory processes affecting the skin," "possible upper respiratory tract infection," "neurological symptoms requiring assessment," "musculoskeletal strain or injury indicators."
    *   **YOU MUST STATE: "This is NOT a diagnosis. These are very general areas a doctor might investigate based on the patterns observed. Only a qualified healthcare professional can provide a diagnosis after a full evaluation."**

6.  **Suggested Next Steps (Actionable, Safe Advice):**
    *   What should the user do? STRONGLY emphasize consulting a doctor/specialist.
    *   Suggest what information from this AI analysis might be useful to share with their doctor (e.g., "You could mention the observed rash in the image and the timeline of symptoms you described.").

7.  **Confidence Assessment (Qualitative, based on medical information quality):**
    *   Assess your confidence (High, Medium, Low) in this multi-modal medical analysis.
    *   Justify it based on the clarity, consistency, and detail of the medical information across inputs: e.g., "High confidence due to consistent description of symptoms in text and clear visual corroboration in the image." or "Medium confidence as the audio quality was poor, limiting detailed analysis of respiratory sounds."

8.  **Important Questions to Ask Doctor (Empower the user for their medical consultation):**
    *   Suggest 2-4 specific, relevant questions the user could ask their healthcare provider to better understand their situation, based on *your analysis*. (e.g., "Could my described fatigue and the rash seen in the image be related?" "What diagnostic tests might be appropriate to investigate the cause of my persistent cough?").

**Output Format:** You MUST respond with a single JSON object that strictly adheres to the \`SuperAnalysisOutputSchema\`. Do not add any text outside this JSON object.
If an input modality is not provided, its corresponding detail field (e.g., \`videoAnalysisDetails\`) can be omitted or explicitly stated as "No video input provided."
Prioritize safety, accuracy in summarizing provided information, and the imperative for professional medical consultation.
`,
});

const superAnalysisFlow = ai.defineFlow(
  {
    name: 'superAnalysisFlow',
    inputSchema: SuperAnalysisInputSchema,
    outputSchema: SuperAnalysisOutputSchema,
  },
  async (input) => {
    const promptInput = { ...input };
    
    // Graceful handling for 503 or other model errors
    try {
      const {output} = await superAnalysisPrompt(promptInput);
      if (!output) {
        // Fallback if output is unexpectedly null
        return {
            overallSummary: "I'm sorry, I couldn't generate a super analysis at this time. Please try again.",
            suggestedNextSteps: "Please try your analysis again. If the problem persists, consider simplifying your input or trying later. Always consult a healthcare professional for medical advice.",
        };
      }
      return output;
    } catch (error: any) {
      console.error('Error in superAnalysisFlow calling superAnalysisPrompt:', error);
      let userMessageSummary = "I'm sorry, something went wrong while trying to perform the super analysis. Please try again later.";
      let userMessageNextSteps = "Please try your analysis again or consult a healthcare professional directly.";

      if (error.message && (error.message.includes('503') || error.message.toLowerCase().includes('service unavailable') || error.message.toLowerCase().includes('model is overloaded'))) {
        userMessageSummary = "The AI service is currently experiencing high demand and could not process your combined inputs. Please try again in a few moments.";
        userMessageNextSteps = "The AI service is overloaded. Please try again later. For urgent concerns, consult a healthcare professional.";
      } else if (error.message && error.message.toLowerCase().includes('candidate was blocked due to safety')) {
         userMessageSummary = "I'm unable to process that specific combination of inputs due to safety guidelines. Could you please try rephrasing or providing different details? Remember, I can't provide medical diagnoses or specific treatment advice.";
         userMessageNextSteps = "Analysis blocked due to safety guidelines. Please consult a doctor for any medical concerns.";
      }
      
      return {
        overallSummary: userMessageSummary,
        suggestedNextSteps: userMessageNextSteps,
        // Optionally, you can provide default/empty values for other fields to match the schema
        symptomBreakdown: [],
        potentialConditions: [],
        importantQuestionsToAskDoctor: [],
      };
    }
  }
);

    
