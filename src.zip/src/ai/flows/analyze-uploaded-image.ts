
'use server';

/**
 * @fileOverview Image analysis flow using Gemini to analyze uploaded images for medical insights.
 *
 * - analyzeUploadedImage - Analyzes an image and provides a category, confidence, and Gemini's advice, focusing on medical visual features.
 * - AnalyzeUploadedImageInput - Input type for the analyzeUploadedImage function.
 * - AnalyzeUploadedImageOutput - Return type for the analyzeUploadedImage function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AnalyzeUploadedImageInputSchema = z.object({
  imageDataUri: z
    .string()
    .describe(
      "A photo, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'. This image is expected to be of a medical nature, like a skin condition, rash, wound, or other visible symptom."
    ),
});
export type AnalyzeUploadedImageInput = z.infer<typeof AnalyzeUploadedImageInputSchema>;

const AnalyzeUploadedImageOutputSchema = z.object({
  category: z.string().describe('The predicted general medical category of the visual feature in the image (e.g., "Inflammatory Skin Condition", "Traumatic Injury Indication", "Pigmented Lesion Characteristics", "Normal Skin Variation", "Unclear Image/Refer to Specialist"). Base this on visual assessment for common medical patterns.'),
  confidence: z.number().min(0).max(1).describe('The AI\'s confidence level (0-1) in its categorization. This reflects the clarity and typicality of the visual signs for the assigned category.'),
  label: z.string().describe('A concise, user-friendly, medically descriptive label for the primary observation (e.g., "Diffuse Red Rash with Papules," "Localized Bruising," "Symmetrical Dark Mole - Common Appearance," "Linear Abrasion").'),
  treatment_offline: z.string().describe('General, non-prescriptive offline care suggestions or monitoring advice relevant to the visual observation. For instance, "Keep the area clean and dry. Avoid irritants. Monitor for changes in size, shape, color, or new symptoms. If concerned, or if the condition worsens, consult a doctor promptly." Avoid specific medical treatments or medications.'),
  gemini_advice: z.string().describe('Detailed AI analysis based on the visual input. Describe what you see (colors, textures, shapes, borders, distribution if applicable) and what these visual cues *might generally indicate in a medical context*, without diagnosing. For example, "The image shows well-demarcated erythematous plaques with silvery scales, which are visual features often associated with certain inflammatory skin conditions." Emphasize that this is not a substitute for professional medical advice and direct the user to see a doctor for any concerns or for a definitive diagnosis.'),
});
export type AnalyzeUploadedImageOutput = z.infer<typeof AnalyzeUploadedImageOutputSchema>;

export async function analyzeUploadedImage(
  input: AnalyzeUploadedImageInput
): Promise<AnalyzeUploadedImageOutput> {
  return analyzeUploadedImageFlow(input);
}

const analyzeUploadedImagePrompt = ai.definePrompt({
  name: 'analyzeUploadedImagePrompt',
  input: {schema: AnalyzeUploadedImageInputSchema},
  output: {schema: AnalyzeUploadedImageOutputSchema},
  prompt: `You are an expert AI medical image analyst. Your task is to carefully examine the provided image (expected to be of a medical nature, e.g., skin condition, wound) and offer insights based purely on visual information. YOU CANNOT PROVIDE A DIAGNOSIS. Your goal is to describe what you see and provide general information.

Image: {{media url=imageDataUri}}
  
Your analysis should include these points, in JSON format:
1.  **Category**: Identify a general medical category for what is visually apparent. Examples: "Inflammatory Skin Condition Signs," "Indications of Traumatic Injury (e.g., bruise, cut)," "Characteristics of Pigmented Lesion," "Appears as Normal Skin Variation," or "Image Unclear - Professional Medical Review Recommended."
2.  **Confidence**: Express your confidence (0.0 to 1.0) in this categorization based on image clarity and distinctiveness of features.
3.  **Label**: Provide a simple, descriptive, medically-oriented label for the main visual finding (e.g., "Scattered Red Papules and Vesicles," "Linear Superficial Abrasion," "Symmetrical Dark Brown Macule with Regular Borders").
4.  **Treatment Offline**: Suggest very general, non-medical advice for self-care or observation. For example: "Keep the area clean. Avoid irritation. Monitor for any changes in size, shape, or color, or if new symptoms like pain or discharge develop. If the condition persists, worsens, or causes concern, it is essential to consult a qualified healthcare professional." Do NOT suggest medications or specific medical treatments.
5.  **Gemini Advice**: Provide a more detailed visual description and interpretation.
    *   Describe the visual characteristics: What colors, shapes, textures, patterns, borders (e.g., regular/irregular), and distribution (e.g., localized, widespread, symmetrical/asymmetrical) do you observe? Is it raised, flat, or depressed?
    *   What might these visual features *generally* suggest in a medical context? (e.g., "Redness and swelling often indicate inflammation." "Irregular borders and multiple colors in a pigmented lesion are features that warrant closer examination by a specialist.").
    *   Critically, emphasize that this visual analysis is for INFORMATIONAL PURPOSES ONLY and IS NOT A MEDICAL DIAGNOSIS. Strongly advise the user to consult a qualified healthcare professional (like a dermatologist or doctor) for any health concerns or for a proper diagnosis and treatment plan. Visual assessment alone is insufficient for diagnosis.

Respond strictly in the JSON format defined by the output schema. Prioritize safety and clarity in your advice.
`,
});

const analyzeUploadedImageFlow = ai.defineFlow(
  {
    name: 'analyzeUploadedImageFlow',
    inputSchema: AnalyzeUploadedImageInputSchema,
    outputSchema: AnalyzeUploadedImageOutputSchema,
  },
  async input => {
    const {output} = await analyzeUploadedImagePrompt(input);
    return output!;
  }
);

    
