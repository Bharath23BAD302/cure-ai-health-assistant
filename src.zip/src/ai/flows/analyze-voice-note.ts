
'use server';

/**
 * @fileOverview This file defines the Genkit flow for analyzing voice notes for medical insights.
 *
 * - analyzeVoiceNote - Analyzes the audio and provides a summary, potential general medical categories, and recommended offline treatments.
 * - AnalyzeVoiceNoteInput - The input type for the analyzeVoiceNote function.
 * - AnalyzeVoiceNoteOutput - The return type for the analyzeVoiceNote function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AnalyzeVoiceNoteInputSchema = z.object({
  audioDataUri: z
    .string()
    .describe(
      'The audio data URI of the voice note. It must include a MIME type and use Base64 encoding. Expected format: \'data:<mimetype>;base64,<encoded_data>\'. The user is likely describing medical symptoms or health concerns.'
    ),
  userId: z.string().optional().describe('The ID of the user uploading the voice note (optional).'),
});

export type AnalyzeVoiceNoteInput = z.infer<typeof AnalyzeVoiceNoteInputSchema>;

const AnalyzeVoiceNoteOutputSchema = z.object({
  summary: z.string().describe('A detailed summary of the voice note, transcribing or paraphrasing the key symptoms, medical concerns, and relevant context (like duration, onset, severity if mentioned) expressed by the user. Capture the essence of their medical message.'),
  potentialDiagnoses: z.string().describe('A list of general categories of medical conditions or types of issues that *could* be related to the described symptoms (e.g., "Possible respiratory infection," "Signs of a common cold," "Inflammatory skin reaction," "Musculoskeletal strain indicators"). This is NOT a diagnosis. This section MUST include a clear disclaimer that it is for informational purposes only and a doctor should be consulted for diagnosis.'),
  recommendedOfflineTreatments: z
    .string()
    .describe('General, non-prescriptive offline self-care advice or next steps. Examples: rest, hydration, monitor symptoms, consider seeing a doctor if symptoms persist or worsen. Avoid specific medication recommendations. This advice must be safe and generally applicable for symptom management before professional consultation.'),
});

export type AnalyzeVoiceNoteOutput = z.infer<typeof AnalyzeVoiceNoteOutputSchema>;

export async function analyzeVoiceNote(
  input: AnalyzeVoiceNoteInput
): Promise<AnalyzeVoiceNoteOutput> {
  return analyzeVoiceNoteFlow(input);
}

const analyzeVoiceNotePrompt = ai.definePrompt({
  name: 'analyzeVoiceNotePrompt',
  input: {schema: AnalyzeVoiceNoteInputSchema},
  output: {schema: AnalyzeVoiceNoteOutputSchema},
  prompt: `You are an AI assistant specialized in analyzing voice notes for potential medical symptoms. Your primary goal is to understand and summarize the user's health concerns and provide general, safe advice. You are NOT a doctor and CANNOT provide a medical diagnosis.

Listen to the following voice note carefully. The user is likely describing their health issues or symptoms:
Voice Note: {{media url=audioDataUri}}
{{#if userId}}User ID: {{{userId}}}{{/if}}

Based on the audio, provide the following in JSON format:
1.  **Summary**: Transcribe or clearly paraphrase the main points from the voice note. Focus on:
    *   What symptoms is the user describing?
    *   What are their concerns?
    *   Did they mention onset, duration, severity, or any treatments tried?
    *   Be as accurate as possible in capturing their expressed medical issues.
2.  **Potential Diagnoses (General Categories)**: Based *only* on the symptoms described in the audio, list a few *general categories* of medical conditions or types of issues that people might experience with such symptoms (e.g., "Possible upper respiratory infection," "Symptoms consistent with a common cold," "Indicators of an inflammatory skin reaction," "Signs suggesting musculoskeletal strain").
    *   **Crucially, state CLEARLY and PROMINENTLY within this field: "This is NOT a medical diagnosis. These are general categories for informational purposes only. A qualified healthcare professional must be consulted for an accurate diagnosis."**
3.  **Recommended Offline Treatments**: Suggest general, non-prescriptive self-care measures or next steps for symptom management before seeing a doctor. Examples: "Ensure adequate rest and hydration. Monitor your symptoms closely. If they persist for more than a few days, worsen, or if you have significant concerns, it is strongly recommended to consult a healthcare professional."
    *   Do NOT recommend specific medications.
    *   This advice should be safe and generally applicable.

Your response must strictly adhere to the JSON format defined by the output schema.
Emphasize throughout your analysis, especially in 'Potential Diagnoses' and 'Recommended Offline Treatments', that the user should consult a healthcare professional for any medical advice or diagnosis. Your role is to inform, not to diagnose or treat.
`,
});

const analyzeVoiceNoteFlow = ai.defineFlow(
  {
    name: 'analyzeVoiceNoteFlow',
    inputSchema: AnalyzeVoiceNoteInputSchema,
    outputSchema: AnalyzeVoiceNoteOutputSchema,
  },
  async (input): Promise<AnalyzeVoiceNoteOutput> => {
    try {
      const {output} = await analyzeVoiceNotePrompt(input);
      if (!output) {
        // This case should ideally not happen if the prompt and model behave as expected.
        // But as a fallback, return a structured error.
        console.warn('analyzeVoiceNotePrompt returned no output for input:', input);
        return {
            summary: "I'm sorry, I couldn't generate a summary for your voice note at this time. Please try again.",
            potentialDiagnoses: "No analysis available. Please consult a doctor for any medical concerns.",
            recommendedOfflineTreatments: "No specific recommendations available. Please try again or consult a healthcare professional.",
        };
      }
      return output;
    } catch (error: any) {
      console.error('Error in analyzeVoiceNoteFlow calling analyzeVoiceNotePrompt:', error);
      let userMessageSummary = "I'm sorry, something went wrong while trying to analyze your voice note. Please try again later.";
      let userMessageDiagnoses = "Analysis unavailable due to an error. Please consult a doctor for any medical concerns.";
      let userMessageTreatments = "Recommendations unavailable due to an error. Please try again or consult a healthcare professional.";

      if (error.message && (error.message.includes('503') || error.message.toLowerCase().includes('service unavailable') || error.message.toLowerCase().includes('model is overloaded'))) {
        userMessageSummary = "The AI service is currently experiencing high demand and could not process your voice note. Please try sending it again in a few moments.";
        userMessageDiagnoses = "AI service is temporarily overloaded. Cannot provide potential categories. Please consult a doctor.";
        userMessageTreatments = "AI service is temporarily overloaded. Cannot provide treatment suggestions. Please consult a doctor.";
      } else if (error.message && error.message.toLowerCase().includes('candidate was blocked due to safety')) {
         userMessageSummary = "I'm unable to process that specific voice note due to safety guidelines. Could you please try rephrasing or providing different details? Remember, I can't provide medical diagnoses or specific treatment advice.";
         userMessageDiagnoses = "Analysis blocked due to safety guidelines. Please consult a doctor for any medical concerns.";
         userMessageTreatments = "Recommendations blocked due to safety guidelines. Please consult a doctor for any medical concerns.";
      }
      
      return {
        summary: userMessageSummary,
        potentialDiagnoses: userMessageDiagnoses,
        recommendedOfflineTreatments: userMessageTreatments,
      };
    }
  }
);

    
