
// SummarizeTextInput.ts
'use server';

/**
 * @fileOverview Summarizes user's symptom description and provides treatment instructions.
 *
 * - summarizeTextInput - A function that accepts a text description of symptoms and returns a summary, impact score, label, offline treatment, Gemini advice, and seriousness assessment.
 * - SummarizeTextInputInput - The input type for the summarizeTextInput function.
 * - SummarizeTextInputOutput - The return type for the summarizeTextInput function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SummarizeTextInputInputSchema = z.object({
  text: z.string().describe('A detailed text description of the user\'s symptoms, including onset, duration, severity, and any related factors.'),
  userId: z.string().optional().describe('The unique identifier of the user (optional).'),
});
export type SummarizeTextInputInput = z.infer<typeof SummarizeTextInputInputSchema>;

const SummarizeTextInputOutputSchema = z.object({
  summary: z.string().describe('A concise summary of the user\'s key symptoms, highlighting main issues and potential concerns from a medical perspective.'),
  impactScore: z.number().min(0).max(100).describe('A numerical score (0-100) indicating the potential severity or impact of the symptoms on daily life. Higher scores indicate greater impact. This should be based on the described symptoms and their nature.'),
  label: z.string().describe('A general medical category or label for the symptoms (e.g., Respiratory, Dermatological, Musculoskeletal, Neurological, Gastrointestinal).'),
  treatmentOffline: z.string().describe('General, non-prescriptive suggestions for offline self-care, symptom management, or steps to consider before seeing a doctor. This advice must be safe and general, not specific medical treatment. For example: "Rest, stay hydrated, monitor symptoms closely."'),
  geminiAdvice: z.string().describe('Detailed AI analysis and insights based on the provided text. This should include: an interpretation of the symptoms in a general medical context, potential (but not specific) underlying mechanisms if patterns are strong, and crucial advice to consult a healthcare professional for diagnosis and treatment. Emphasize that this is AI-generated information and not a substitute for professional medical advice.'),
  seriousness: z.enum(['low', 'medium', 'high']).describe('An assessment of the potential seriousness of the symptoms (low, medium, or high), considering factors like duration, severity, type of symptoms described, and potential red flags if any are mentioned. This is not a diagnosis but a general indication of urgency for seeking professional advice.'),
});
export type SummarizeTextInputOutput = z.infer<typeof SummarizeTextInputOutputSchema>;

export async function summarizeTextInput(input: SummarizeTextInputInput): Promise<SummarizeTextInputOutput> {
  return summarizeTextInputFlow(input);
}

const summarizeTextInputPrompt = ai.definePrompt({
  name: 'summarizeTextInputPrompt',
  input: {schema: SummarizeTextInputInputSchema},
  output: {schema: SummarizeTextInputOutputSchema},
  prompt: `You are an AI healthcare assistant. Your task is to analyze the user's symptom description from a medical perspective to provide helpful, general information, NOT a medical diagnosis.

User's Symptom Description:
"{{{text}}}"
{{#if userId}}User ID: {{{userId}}}{{/if}}

Based on this description, please provide the following in JSON format:
1.  **Summary**: Concisely summarize the key symptoms mentioned by the user. What are the main medical complaints and observations?
2.  **Impact Score**: Estimate an impact score from 0 (no impact) to 100 (severe impact on daily life). Consider the described severity, duration (if mentioned), and number/nature of symptoms from a health impact view.
3.  **Label**: Assign a broad medical category label to the symptoms (e.g., Respiratory Issue, Skin Condition, Digestive Comfort, General Malaise, Musculoskeletal Pain, Neurological Concern).
4.  **Treatment Offline**: Suggest general, non-prescriptive offline self-care measures or actions the user might consider (e.g., rest, hydration, monitor symptoms). THIS IS NOT MEDICAL TREATMENT. Avoid specific medication recommendations. Emphasize that these are general suggestions.
5.  **Gemini Advice**: Offer detailed AI analysis.
    *   Interpret the symptoms in a general medical context. What might these symptoms commonly suggest?
    *   If there are patterns, what *general* physiological processes might be involved?
    *   Crucially, reiterate that this analysis IS NOT A DIAGNOSIS and a qualified healthcare professional (e.g., a doctor) MUST be consulted for any medical concerns, diagnosis, and treatment plan. This AI-generated information is for informational purposes only.
6.  **Seriousness**: Assess the potential seriousness as 'low', 'medium', 'high'.
    *   'Low': Mild, common symptoms, likely self-resolving.
    *   'Medium': Persistent, bothersome symptoms, or those that might benefit from medical attention if they don't improve.
    *   'High': Symptoms that sound acute, severe, involve red flags (e.g., severe pain, difficulty breathing, sudden changes, neurological deficits mentioned), or are typically associated with conditions needing prompt medical attention. Base this assessment strictly on the text provided.

Your response must strictly adhere to the JSON format defined by the output schema.
Your primary role is to provide information and strongly guide the user to seek professional medical help.
`,
});

const summarizeTextInputFlow = ai.defineFlow(
  {
    name: 'summarizeTextInputFlow',
    inputSchema: SummarizeTextInputInputSchema,
    outputSchema: SummarizeTextInputOutputSchema,
  },
  async input => {
    const {output} = await summarizeTextInputPrompt(input);
    return output!;
  }
);

    
