
'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, Mic, Image as ImageIcon, Menu, Video as VideoIcon, Sparkles, Bot } from 'lucide-react'; // Removed Blend
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger, SheetClose } from '@/components/ui/sheet';
import { cn } from '@/lib/utils';
import * as React from 'react';

const NavLink = ({ href, children, icon: Icon, onClick }: { href: string; children: React.ReactNode; icon: React.ElementType; onClick?: () => void }) => {
  const pathname = usePathname();
  const isActive = pathname === href;

  return (
    <Link href={href} passHref legacyBehavior>
      <a
        onClick={onClick}
        className={cn(
          "flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors",
          isActive ? "bg-primary/10 text-primary" : "text-foreground/70 hover:text-foreground hover:bg-muted"
        )}
      >
        <Icon className="h-5 w-5" />
        {children}
      </a>
    </Link>
  );
};


const MobileNavLink = ({ href, children, icon: Icon, closeSheet }: { href: string; children: React.ReactNode; icon: React.ElementType, closeSheet: () => void }) => {
  const pathname = usePathname();
  const isActive = pathname === href;

  return (
    <SheetClose asChild>
      <Link href={href} passHref legacyBehavior>
        <a
          onClick={closeSheet}
          className={cn(
            "flex items-center gap-3 px-4 py-3 rounded-md text-base font-medium transition-colors",
            isActive ? "bg-primary/10 text-primary" : "text-foreground hover:bg-muted"
          )}
        >
          <Icon className="h-6 w-6" />
          {children}
        </a>
      </Link>
    </SheetClose>
  );
};


export default function Navbar() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  const closeMobileMenu = () => setIsMobileMenuOpen(false);

  const navItems = [
    { href: '/', label: 'Chat AI', icon: Bot },
    { href: '/voice', label: 'Voice', icon: Mic },
    { href: '/image', label: 'Image', icon: ImageIcon },
    { href: '/video', label: 'Video', icon: VideoIcon },
    // { href: '/audio-image-combo', label: 'Audio & Image', icon: Blend }, // Removed
    { href: '/super-analysis', label: 'Super Analysis', icon: Sparkles },
  ];


  return (
    <header className="sticky top-0 z-50 w-full border-b bg-card shadow-sm print:hidden">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="text-xl font-bold text-primary flex items-center">
          <Sparkles className="w-6 h-6 mr-1.5 text-primary" />
          CURE-AI Pro
        </Link>

        <nav className="hidden md:flex items-center space-x-1">
          {navItems.map((item) => (
            <NavLink key={item.href} href={item.href} icon={item.icon}>
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="md:hidden">
          <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
                <span className="sr-only">Open menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-full max-w-xs bg-card p-0">
              <div className="flex flex-col h-full">
                <div className="p-4 border-b flex items-center">
                   <Sparkles className="w-5 h-5 mr-1.5 text-primary" />
                  <Link href="/" onClick={closeMobileMenu} className="text-lg font-bold text-primary">
                    CURE-AI Pro
                  </Link>
                </div>
                <nav className="flex-grow p-4 space-y-2">
                  {navItems.map((item) => (
                     <MobileNavLink key={item.href} href={item.href} icon={item.icon} closeSheet={closeMobileMenu}>
                       {item.label}
                     </MobileNavLink>
                  ))}
                </nav>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}

    