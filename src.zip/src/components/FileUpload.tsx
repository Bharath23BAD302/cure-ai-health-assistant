'use client';

import { useState, useRef, ChangeEvent, DragEvent, ReactNode } from 'react';
import { UploadCloud } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

interface FileUploadProps {
  onFileSelect: (file: File) => void;
  accept: string;
  buttonText?: string;
  children?: ReactNode;
  className?: string;
}

export default function FileUpload({
  onFileSelect,
  accept,
  buttonText = 'Select File',
  children,
  className,
}: FileUploadProps) {
  const [dragging, setDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      onFileSelect(file);
    }
  };

  const handleButtonClick = () => {
    fileInputRef.current?.click();
  };

  const handleDragEnter = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragging(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragging(false);
  };

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.match(accept.replace('*', '.*'))) {
      onFileSelect(file);
      if(fileInputRef.current) {
        fileInputRef.current.files = e.dataTransfer.files;
      }
    } else {
      // Handle invalid file type
      console.warn('Invalid file type dropped.');
    }
  };

  return (
    <div
      className={cn(
        "border-2 border-dashed border-muted-foreground/50 rounded-lg p-8 text-center cursor-pointer hover:border-primary transition-colors",
        dragging && "border-primary bg-primary/10",
        className
      )}
      onClick={handleButtonClick}
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
    >
      <Input
        type="file"
        accept={accept}
        onChange={handleFileChange}
        ref={fileInputRef}
        className="hidden"
        id={`file-upload-${accept.replace(/[^a-zA-Z0-9]/g, '')}`} 
      />
      <div className="flex flex-col items-center justify-center space-y-4">
        {children ? (
          children
        ) : (
          <>
            <UploadCloud className="w-12 h-12 text-muted-foreground" />
            <p className="text-muted-foreground">
              Drag & drop your file here, or click to select.
            </p>
            <Button type="button" variant="outline" onClick={handleButtonClick} className="pointer-events-none"> {/* Make button non-interactive as div handles click */}
              {buttonText}
            </Button>
          </>
        )}
      </div>
    </div>
  );
}
