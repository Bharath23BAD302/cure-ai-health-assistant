
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import type { 
    SummarizeTextInputOutput, 
    AnalyzeVoiceNoteOutput, 
    AnalyzeUploadedImageOutput, 
    // AnalyzeAudioImageComboOutput, // Removed
    AnalyzeVideoOutput,
    SuperAnalysisOutput
} from '@/types'; // Ensure all types are imported from a central place or directly
import { CheckCircle, AlertCircle, Info, MessageSquare, Microscope, ListChecks, HelpCircle, Mic as MicIcon, Image as ImageIcon, Video as VideoIcon, FileText } from 'lucide-react'; // Added specific icons

type ResultsCardProps = {
  mode: 'text' | 'audio' | 'image' | 'video' | 'super-analysis'; // Removed 'audio-image'
  data: SummarizeTextInputOutput | AnalyzeVoiceNoteOutput | AnalyzeUploadedImageOutput | AnalyzeVideoOutput | SuperAnalysisOutput; // AnalyzeAudioImageComboOutput removed
};

const getImpactScoreBadgeVariant = (score: number): 'default' | 'secondary' | 'destructive' => {
  if (score >= 75) return 'destructive'; 
  if (score >= 40) return 'secondary'; 
  return 'default'; 
};

const getSeriousnessBadgeVariant = (seriousness?: 'low' | 'medium' | 'high'): 'default' | 'secondary' | 'destructive' | undefined => {
  if (!seriousness) return undefined;
  if (seriousness === 'high') return 'destructive';
  if (seriousness === 'medium') return 'secondary';
  return 'default'; 
};

const getConfidenceBadgeVariant = (confidence?: string): 'default' | 'secondary' | 'destructive' | 'outline' | undefined => {
    if (!confidence) return undefined;
    const lowerConfidence = confidence.toLowerCase();
    if (lowerConfidence.includes('high')) return 'default'; 
    if (lowerConfidence.includes('medium')) return 'secondary'; 
    if (lowerConfidence.includes('low')) return 'destructive'; 
    return 'outline';
};


const ResultSection: React.FC<{ title: string; icon?: React.ReactNode; children: React.ReactNode; defaultOpen?: boolean }> = ({ title, icon, children, defaultOpen = false }) => (
  <AccordionItem value={title} className="border-b-0 last:border-b-0">
    <AccordionTrigger className="text-lg font-semibold hover:no-underline py-3 px-1">
      <div className="flex items-center">
        {icon && <span className="mr-2 text-primary">{icon}</span>}
        {title}
      </div>
    </AccordionTrigger>
    <AccordionContent className="pb-4 px-1 text-sm">
      {children}
    </AccordionContent>
  </AccordionItem>
);

export default function ResultsCard({ mode, data }: ResultsCardProps) {
  const textData = mode === 'text' ? data as SummarizeTextInputOutput : null;
  const imageData = mode === 'image' ? data as AnalyzeUploadedImageOutput : null;
  const audioData = mode === 'audio' ? data as AnalyzeVoiceNoteOutput : null;
  // const audioImageData = mode === 'audio-image' ? data as AnalyzeAudioImageComboOutput : null; // Removed
  const videoData = mode === 'video' ? data as AnalyzeVideoOutput : null;
  const superData = mode === 'super-analysis' ? data as SuperAnalysisOutput : null;

  const seriousnessVariant = textData?.seriousness ? getSeriousnessBadgeVariant(textData.seriousness) : undefined;
  const confidenceVariant = superData?.confidenceAssessment ? getConfidenceBadgeVariant(superData.confidenceAssessment) : undefined;
  
  const modeTitles = {
      text: "Text Analysis Results",
      audio: "Voice Note Analysis Results",
      image: "Image Analysis Results",
      // 'audio-image': "Audio & Image Combo Analysis", // Removed
      video: "Video Analysis Results",
      'super-analysis': "Super Analysis Detailed Report"
  };

  return (
    <Card className="w-full shadow-lg mt-6">
      <CardHeader className="border-b">
        <CardTitle className="text-2xl font-bold text-primary">{modeTitles[mode]}</CardTitle>
        <CardDescription>Comprehensive AI-generated insights based on your input.</CardDescription>
      </CardHeader>
      <CardContent className="pt-6 space-y-3">
        <Accordion type="multiple" defaultValue={superData ? ['Overall Summary'] : (textData || imageData || audioData || videoData) ? undefined : []} className="w-full">
            {textData && (
            <>
                <ResultSection title="Symptom Summary" icon={<Info />}>
                    <p className="text-base font-semibold">{textData.summary}</p>
                </ResultSection>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 my-4 px-1">
                    <div>
                        <h4 className="font-medium text-sm mb-1">Impact Score</h4>
                        <Badge variant={getImpactScoreBadgeVariant(textData.impactScore)} className="text-base px-3 py-1">
                        {textData.impactScore} / 100
                        </Badge>
                    </div>
                    {textData.seriousness && seriousnessVariant && (
                    <div>
                        <h4 className="font-medium text-sm mb-1">Seriousness Assessment</h4>
                        <Badge variant={seriousnessVariant} className="text-base px-3 py-1">
                        {textData.seriousness.charAt(0).toUpperCase() + textData.seriousness.slice(1)}
                        </Badge>
                    </div>
                    )}
                </div>
                <ResultSection title="Category Label" icon={<ListChecks />}>
                    <p>{textData.label}</p>
                </ResultSection>
                <ResultSection title="Offline Treatment Suggestions" icon={<HelpCircle />}>
                    <p className="italic">{textData.treatmentOffline}</p>
                </ResultSection>
                <ResultSection title="Gemini AI Advice" icon={<MessageSquare />}>
                    <ScrollArea className="h-32 p-2 border rounded-md bg-muted/50"><p>{textData.geminiAdvice}</p></ScrollArea>
                </ResultSection>
            </>
            )}

            {imageData && (
            <>
                <ResultSection title="Predicted Category" icon={<Info />}>
                    <p className="text-base font-semibold">{imageData.category}</p>
                </ResultSection>
                 <div className="my-4 px-1">
                    <h4 className="font-medium text-sm mb-1">Confidence</h4>
                    <div className="flex items-center gap-2">
                        <Progress value={imageData.confidence * 100} className="w-full h-2.5" />
                        <span>{(imageData.confidence * 100).toFixed(0)}%</span>
                    </div>
                </div>
                <ResultSection title="Assigned Label" icon={<ListChecks />}>
                    <p>{imageData.label}</p>
                </ResultSection>
                <ResultSection title="Offline Treatment Suggestions" icon={<HelpCircle />}>
                    <p className="italic">{imageData.treatment_offline}</p>
                </ResultSection>
                <ResultSection title="Gemini AI Advice" icon={<MessageSquare />}>
                    <ScrollArea className="h-32 p-2 border rounded-md bg-muted/50"><p>{imageData.gemini_advice}</p></ScrollArea>
                </ResultSection>
            </>
            )}

            {audioData && (
            <>
                <ResultSection title="Voice Note Summary" icon={<Info />}>
                    <p>{audioData.summary}</p>
                </ResultSection>
                <ResultSection title="Potential Diagnoses (General)" icon={<ListChecks />}>
                    <ScrollArea className="h-24 p-2 border rounded-md bg-muted/50"><p>{audioData.potentialDiagnoses}</p></ScrollArea>
                </ResultSection>
                <ResultSection title="Recommended Offline Treatments" icon={<HelpCircle />}>
                    <ScrollArea className="h-32 p-2 border rounded-md bg-muted/50"><p>{audioData.recommendedOfflineTreatments}</p></ScrollArea>
                </ResultSection>
            </>
            )}
            
            {/* audioImageData section removed */}

            {videoData && (
            <>
                <ResultSection title="Video Summary" icon={<Info />}>
                    <p>{videoData.summary}</p>
                </ResultSection>
                <ResultSection title="Key Observations from Video" icon={<Microscope />}>
                    {videoData.keyObservations.length > 0 ? (
                         <ScrollArea className="h-32 p-2 border rounded-md bg-muted/50">
                            <ul className="list-disc list-inside space-y-1">
                                {videoData.keyObservations.map((obs, index) => (<li key={index}>{obs}</li>))}
                            </ul>
                        </ScrollArea>
                    ) : <p className="text-muted-foreground">No specific key observations noted.</p>}
                </ResultSection>
                <ResultSection title="Potential Concerns from Video" icon={<AlertCircle />}>
                     <p>{videoData.potentialConcerns || "No specific concerns highlighted."}</p>
                </ResultSection>
                {videoData.durationApproximation && (
                    <ResultSection title="Video Duration (Approx.)" icon={<ListChecks />}>
                        <p>{videoData.durationApproximation}</p>
                    </ResultSection>
                )}
            </>
            )}

            {superData && (
            <>
                <ResultSection title="Overall Summary" icon={<Info />} defaultOpen>
                    <p className="text-base">{superData.overallSummary}</p>
                </ResultSection>

                {superData.confidenceAssessment && confidenceVariant && (
                     <div className="my-4 px-1">
                        <h4 className="font-medium text-sm mb-1">Confidence Assessment</h4>
                        <Badge variant={confidenceVariant} className="text-base px-3 py-1">
                            {superData.confidenceAssessment}
                        </Badge>
                    </div>
                )}

                {superData.symptomBreakdown && superData.symptomBreakdown.length > 0 && (
                    <ResultSection title="Symptom & Observation Breakdown" icon={<ListChecks />}>
                        <ScrollArea className="h-40 p-2 border rounded-md bg-muted/50">
                        {superData.symptomBreakdown.map((item, index) => (
                            <div key={index} className="mb-2 p-2 rounded bg-background/50">
                                <p className="font-semibold">{item.symptom}</p>
                                <p className="text-xs text-muted-foreground">Mentioned in: {item.mentionedIn.join(', ')}</p>
                            </div>
                        ))}
                        </ScrollArea>
                    </ResultSection>
                )}
                
                {superData.textAnalysisDetails && (
                    <ResultSection title="Text Analysis Details" icon={<FileText />}><p>{superData.textAnalysisDetails}</p></ResultSection>
                )}
                {superData.audioAnalysisDetails && (
                    <ResultSection title="Audio Analysis Details" icon={<MicIcon />}><p>{superData.audioAnalysisDetails}</p></ResultSection>
                )}
                {superData.imageAnalysisDetails && (
                    <ResultSection title="Image Analysis Details" icon={<ImageIcon />}><p>{superData.imageAnalysisDetails}</p></ResultSection>
                )}
                {superData.videoAnalysisDetails && (
                    <ResultSection title="Video Analysis Details" icon={<VideoIcon />}><p>{superData.videoAnalysisDetails}</p></ResultSection>
                )}

                {superData.potentialConditions && superData.potentialConditions.length > 0 && (
                    <ResultSection title="Potential Conditions (General Categories)" icon={<AlertCircle />}>
                        <ul className="list-disc list-inside space-y-1 p-2 border rounded-md bg-muted/50">
                            {superData.potentialConditions.map((condition, index) => (<li key={index}>{condition}</li>))}
                        </ul>
                        <p className="mt-2 text-xs text-destructive">Note: This is not a diagnosis. Consult a healthcare professional.</p>
                    </ResultSection>
                )}
                 {superData.importantQuestionsToAskDoctor && superData.importantQuestionsToAskDoctor.length > 0 && (
                    <ResultSection title="Questions for Your Doctor" icon={<HelpCircle />}>
                         <ul className="list-disc list-inside space-y-1 p-2 border rounded-md bg-muted/50">
                            {superData.importantQuestionsToAskDoctor.map((question, index) => (<li key={index}>{question}</li>))}
                        </ul>
                    </ResultSection>
                )}
                 <ResultSection title="Suggested Next Steps" icon={<CheckCircle />} defaultOpen>
                    <p>{superData.suggestedNextSteps || "Please review the analysis and consider consulting a healthcare professional if you have concerns."}</p>
                </ResultSection>
                {superData.chatReply && (
                     <ResultSection title="AI Chat Reply Context" icon={<MessageSquare />}>
                        <p className="italic">{superData.chatReply}</p>
                    </ResultSection>
                )}
            </>
            )}
        </Accordion>
      </CardContent>
    </Card>
  );
}

    