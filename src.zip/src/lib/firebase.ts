
import { initializeApp, getApps, FirebaseApp } from 'firebase/app';
import { getAuth, Auth } from 'firebase/auth';
import { getFirestore, Firestore } from 'firebase/firestore';
import { getStorage, FirebaseStorage } from 'firebase/storage';
import appConfig from '@/config';

const firebaseEnvConfig = {
  apiKey: appConfig.firebase.apiKey,
  authDomain: appConfig.firebase.authDomain,
  projectId: appConfig.firebase.projectId,
  storageBucket: appConfig.firebase.storageBucket,
  messagingSenderId: appConfig.firebase.messagingSenderId,
  appId: appConfig.firebase.appId,
};

let app: FirebaseApp | null = null;
let authInstance: Auth | null = null;
let dbInstance: Firestore | null = null;
let storageInstance: FirebaseStorage | null = null;
let firebaseInitialized = false;

if (
  firebaseEnvConfig.apiKey && !firebaseEnvConfig.apiKey.includes('YOUR_') && !firebaseEnvConfig.apiKey.includes('XXXX') &&
  firebaseEnvConfig.authDomain && !firebaseEnvConfig.authDomain.includes('YOUR_') &&
  firebaseEnvConfig.projectId && !firebaseEnvConfig.projectId.includes('YOUR_')
) {
  if (!getApps().length) {
    try {
      app = initializeApp(firebaseEnvConfig);
      authInstance = getAuth(app);
      dbInstance = getFirestore(app);
      storageInstance = getStorage(app);
      firebaseInitialized = true;
    } catch (e) {
      console.error("Firebase initialization failed:", e);
      // app, authInstance, etc., remain null
    }
  } else {
    app = getApps()[0];
    // Ensure these instances are derived from the potentially re-initialized 'app'
    // This assumes the existing app was initialized with a compatible config.
    // If a different config was used, this might still lead to issues.
    // However, for typical SPA usage, getApps()[0] is the correct approach.
    try {
        authInstance = getAuth(app);
        dbInstance = getFirestore(app);
        storageInstance = getStorage(app);
        firebaseInitialized = true;
    } catch (e) {
        console.error("Firebase getService instances failed after app already initialized:", e);
    }
  }
} else {
  console.warn(
    "Firebase configuration is missing, incomplete, or uses placeholder values. " +
    "Please ensure NEXT_PUBLIC_FIREBASE_API_KEY, NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN, " +
    "and NEXT_PUBLIC_FIREBASE_PROJECT_ID are correctly set with valid values in your .env.local file. " +
    "Firebase-dependent features will be unavailable."
  );
}

export { app, authInstance as auth, dbInstance as db, storageInstance as storage, firebaseInitialized };
