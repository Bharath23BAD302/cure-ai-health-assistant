
import {
  doc,
  setDoc,
  addDoc,
  collection,
  query,
  orderBy,
  limit,
  getDocs,
  serverTimestamp,
  updateDoc,
  Timestamp,
  where,
  getDoc,
} from 'firebase/firestore';
import { db as firestoreDb, storage as firebaseStorage, firebaseInitialized } from './firebase';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import type { UserProfile, Consultation, TextConsultation, AudioConsultation, ImageConsultation } from '@/types';

export const createUserProfileDocument = async (userAuth: any, additionalData?: object) => {
  if (!firebaseInitialized || !firestoreDb) {
    console.error("Firestore is not initialized. Cannot create user profile.");
    throw new Error("Firestore is not initialized.");
  }
  if (!userAuth) return;

  const userRef = doc(firestoreDb, `users/${userAuth.uid}`);
  const snapshot = await getDoc(userRef);

  if (!snapshot.exists()) {
    const { email } = userAuth;
    const createdAt = serverTimestamp();
    try {
      await setDoc(userRef, {
        uid: userAuth.uid,
        email,
        displayName: '',
        photoURL: '',
        createdAt,
        ...additionalData,
      });
    } catch (error) {
      console.error('Error creating user profile: ', error);
      throw error;
    }
  }
  return userRef;
};

export const updateUserProfile = async (uid: string, data: Partial<UserProfile>): Promise<void> => {
  if (!firebaseInitialized || !firestoreDb) {
    console.error("Firestore is not initialized. Cannot update user profile.");
    throw new Error("Firestore is not initialized.");
  }
  const userRef = doc(firestoreDb, 'users', uid);
  await updateDoc(userRef, data);
};

export const uploadProfilePhoto = async (uid: string, file: File): Promise<string> => {
  if (!firebaseInitialized || !firebaseStorage) {
    console.error("Firebase Storage is not initialized. Cannot upload profile photo.");
    throw new Error("Firebase Storage is not initialized.");
  }
  const filePath = `profileImages/${uid}/${file.name}`;
  const storageRef = ref(firebaseStorage, filePath);
  await uploadBytes(storageRef, file);
  const downloadURL = await getDownloadURL(storageRef);
  return downloadURL;
};

export const addConsultation = async (
  uid: string,
  consultationData: Omit<TextConsultation, 'id' | 'createdAt'> | Omit<AudioConsultation, 'id' | 'createdAt'> | Omit<ImageConsultation, 'id' | 'createdAt'>
): Promise<void> => {
  if (!firebaseInitialized || !firestoreDb) {
    console.error("Firestore is not initialized. Cannot add consultation.");
    throw new Error("Firestore is not initialized.");
  }
  const consultationsRef = collection(firestoreDb, `users/${uid}/consultations`);
  await addDoc(consultationsRef, {
    ...consultationData,
    createdAt: serverTimestamp(),
  });
};

export const getConsultations = async (uid: string, count: number = 10): Promise<Consultation[]> => {
  if (!firebaseInitialized || !firestoreDb) {
    console.error("Firestore is not initialized. Cannot get consultations.");
    return []; // Return empty array or throw error
  }
  const consultationsRef = collection(firestoreDb, `users/${uid}/consultations`);
  const q = query(consultationsRef, orderBy('createdAt', 'desc'), limit(count));
  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(docSnap => ({
    id: docSnap.id,
    ...docSnap.data(),
  } as Consultation));
};

export const getFileAsDataURL = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
    reader.readAsDataURL(file);
  });
};
